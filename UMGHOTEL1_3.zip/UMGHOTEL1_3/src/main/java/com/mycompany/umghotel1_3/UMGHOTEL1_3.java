/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.umghotel1_3;

/**
 *
 * @author Usser_401
 */
public class UMGHOTEL1_3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
