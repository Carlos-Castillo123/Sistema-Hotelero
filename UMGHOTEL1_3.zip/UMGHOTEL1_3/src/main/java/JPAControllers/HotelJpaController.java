/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JPAControllers;

import EntityClases.Empleados;
import EntityClases.Facturas;
import EntityClases.Habitaciones;
import EntityClases.Hotel;
import EntityClases.Reservaciones;
import JPAControllers.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Usser_401
 */
public class HotelJpaController implements Serializable {

    public HotelJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Hotel hotel) {
        if (hotel.getHabitacionesCollection() == null) {
            hotel.setHabitacionesCollection(new ArrayList<Habitaciones>());
        }
        if (hotel.getEmpleadosCollection() == null) {
            hotel.setEmpleadosCollection(new ArrayList<Empleados>());
        }
        if (hotel.getReservacionesCollection() == null) {
            hotel.setReservacionesCollection(new ArrayList<Reservaciones>());
        }
        if (hotel.getFacturasCollection() == null) {
            hotel.setFacturasCollection(new ArrayList<Facturas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Habitaciones> attachedHabitacionesCollection = new ArrayList<Habitaciones>();
            for (Habitaciones habitacionesCollectionHabitacionesToAttach : hotel.getHabitacionesCollection()) {
                habitacionesCollectionHabitacionesToAttach = em.getReference(habitacionesCollectionHabitacionesToAttach.getClass(), habitacionesCollectionHabitacionesToAttach.getIdHabitacion());
                attachedHabitacionesCollection.add(habitacionesCollectionHabitacionesToAttach);
            }
            hotel.setHabitacionesCollection(attachedHabitacionesCollection);
            Collection<Empleados> attachedEmpleadosCollection = new ArrayList<Empleados>();
            for (Empleados empleadosCollectionEmpleadosToAttach : hotel.getEmpleadosCollection()) {
                empleadosCollectionEmpleadosToAttach = em.getReference(empleadosCollectionEmpleadosToAttach.getClass(), empleadosCollectionEmpleadosToAttach.getIdEmpleado());
                attachedEmpleadosCollection.add(empleadosCollectionEmpleadosToAttach);
            }
            hotel.setEmpleadosCollection(attachedEmpleadosCollection);
            Collection<Reservaciones> attachedReservacionesCollection = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionReservacionesToAttach : hotel.getReservacionesCollection()) {
                reservacionesCollectionReservacionesToAttach = em.getReference(reservacionesCollectionReservacionesToAttach.getClass(), reservacionesCollectionReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollection.add(reservacionesCollectionReservacionesToAttach);
            }
            hotel.setReservacionesCollection(attachedReservacionesCollection);
            Collection<Facturas> attachedFacturasCollection = new ArrayList<Facturas>();
            for (Facturas facturasCollectionFacturasToAttach : hotel.getFacturasCollection()) {
                facturasCollectionFacturasToAttach = em.getReference(facturasCollectionFacturasToAttach.getClass(), facturasCollectionFacturasToAttach.getIdFactura());
                attachedFacturasCollection.add(facturasCollectionFacturasToAttach);
            }
            hotel.setFacturasCollection(attachedFacturasCollection);
            em.persist(hotel);
            for (Habitaciones habitacionesCollectionHabitaciones : hotel.getHabitacionesCollection()) {
                Hotel oldIdHotelOfHabitacionesCollectionHabitaciones = habitacionesCollectionHabitaciones.getIdHotel();
                habitacionesCollectionHabitaciones.setIdHotel(hotel);
                habitacionesCollectionHabitaciones = em.merge(habitacionesCollectionHabitaciones);
                if (oldIdHotelOfHabitacionesCollectionHabitaciones != null) {
                    oldIdHotelOfHabitacionesCollectionHabitaciones.getHabitacionesCollection().remove(habitacionesCollectionHabitaciones);
                    oldIdHotelOfHabitacionesCollectionHabitaciones = em.merge(oldIdHotelOfHabitacionesCollectionHabitaciones);
                }
            }
            for (Empleados empleadosCollectionEmpleados : hotel.getEmpleadosCollection()) {
                Hotel oldIdHotelOfEmpleadosCollectionEmpleados = empleadosCollectionEmpleados.getIdHotel();
                empleadosCollectionEmpleados.setIdHotel(hotel);
                empleadosCollectionEmpleados = em.merge(empleadosCollectionEmpleados);
                if (oldIdHotelOfEmpleadosCollectionEmpleados != null) {
                    oldIdHotelOfEmpleadosCollectionEmpleados.getEmpleadosCollection().remove(empleadosCollectionEmpleados);
                    oldIdHotelOfEmpleadosCollectionEmpleados = em.merge(oldIdHotelOfEmpleadosCollectionEmpleados);
                }
            }
            for (Reservaciones reservacionesCollectionReservaciones : hotel.getReservacionesCollection()) {
                Hotel oldIdHotelOfReservacionesCollectionReservaciones = reservacionesCollectionReservaciones.getIdHotel();
                reservacionesCollectionReservaciones.setIdHotel(hotel);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
                if (oldIdHotelOfReservacionesCollectionReservaciones != null) {
                    oldIdHotelOfReservacionesCollectionReservaciones.getReservacionesCollection().remove(reservacionesCollectionReservaciones);
                    oldIdHotelOfReservacionesCollectionReservaciones = em.merge(oldIdHotelOfReservacionesCollectionReservaciones);
                }
            }
            for (Facturas facturasCollectionFacturas : hotel.getFacturasCollection()) {
                Hotel oldIdHotelOfFacturasCollectionFacturas = facturasCollectionFacturas.getIdHotel();
                facturasCollectionFacturas.setIdHotel(hotel);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
                if (oldIdHotelOfFacturasCollectionFacturas != null) {
                    oldIdHotelOfFacturasCollectionFacturas.getFacturasCollection().remove(facturasCollectionFacturas);
                    oldIdHotelOfFacturasCollectionFacturas = em.merge(oldIdHotelOfFacturasCollectionFacturas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Hotel hotel) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Hotel persistentHotel = em.find(Hotel.class, hotel.getIdHotel());
            Collection<Habitaciones> habitacionesCollectionOld = persistentHotel.getHabitacionesCollection();
            Collection<Habitaciones> habitacionesCollectionNew = hotel.getHabitacionesCollection();
            Collection<Empleados> empleadosCollectionOld = persistentHotel.getEmpleadosCollection();
            Collection<Empleados> empleadosCollectionNew = hotel.getEmpleadosCollection();
            Collection<Reservaciones> reservacionesCollectionOld = persistentHotel.getReservacionesCollection();
            Collection<Reservaciones> reservacionesCollectionNew = hotel.getReservacionesCollection();
            Collection<Facturas> facturasCollectionOld = persistentHotel.getFacturasCollection();
            Collection<Facturas> facturasCollectionNew = hotel.getFacturasCollection();
            Collection<Habitaciones> attachedHabitacionesCollectionNew = new ArrayList<Habitaciones>();
            for (Habitaciones habitacionesCollectionNewHabitacionesToAttach : habitacionesCollectionNew) {
                habitacionesCollectionNewHabitacionesToAttach = em.getReference(habitacionesCollectionNewHabitacionesToAttach.getClass(), habitacionesCollectionNewHabitacionesToAttach.getIdHabitacion());
                attachedHabitacionesCollectionNew.add(habitacionesCollectionNewHabitacionesToAttach);
            }
            habitacionesCollectionNew = attachedHabitacionesCollectionNew;
            hotel.setHabitacionesCollection(habitacionesCollectionNew);
            Collection<Empleados> attachedEmpleadosCollectionNew = new ArrayList<Empleados>();
            for (Empleados empleadosCollectionNewEmpleadosToAttach : empleadosCollectionNew) {
                empleadosCollectionNewEmpleadosToAttach = em.getReference(empleadosCollectionNewEmpleadosToAttach.getClass(), empleadosCollectionNewEmpleadosToAttach.getIdEmpleado());
                attachedEmpleadosCollectionNew.add(empleadosCollectionNewEmpleadosToAttach);
            }
            empleadosCollectionNew = attachedEmpleadosCollectionNew;
            hotel.setEmpleadosCollection(empleadosCollectionNew);
            Collection<Reservaciones> attachedReservacionesCollectionNew = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionNewReservacionesToAttach : reservacionesCollectionNew) {
                reservacionesCollectionNewReservacionesToAttach = em.getReference(reservacionesCollectionNewReservacionesToAttach.getClass(), reservacionesCollectionNewReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollectionNew.add(reservacionesCollectionNewReservacionesToAttach);
            }
            reservacionesCollectionNew = attachedReservacionesCollectionNew;
            hotel.setReservacionesCollection(reservacionesCollectionNew);
            Collection<Facturas> attachedFacturasCollectionNew = new ArrayList<Facturas>();
            for (Facturas facturasCollectionNewFacturasToAttach : facturasCollectionNew) {
                facturasCollectionNewFacturasToAttach = em.getReference(facturasCollectionNewFacturasToAttach.getClass(), facturasCollectionNewFacturasToAttach.getIdFactura());
                attachedFacturasCollectionNew.add(facturasCollectionNewFacturasToAttach);
            }
            facturasCollectionNew = attachedFacturasCollectionNew;
            hotel.setFacturasCollection(facturasCollectionNew);
            hotel = em.merge(hotel);
            for (Habitaciones habitacionesCollectionOldHabitaciones : habitacionesCollectionOld) {
                if (!habitacionesCollectionNew.contains(habitacionesCollectionOldHabitaciones)) {
                    habitacionesCollectionOldHabitaciones.setIdHotel(null);
                    habitacionesCollectionOldHabitaciones = em.merge(habitacionesCollectionOldHabitaciones);
                }
            }
            for (Habitaciones habitacionesCollectionNewHabitaciones : habitacionesCollectionNew) {
                if (!habitacionesCollectionOld.contains(habitacionesCollectionNewHabitaciones)) {
                    Hotel oldIdHotelOfHabitacionesCollectionNewHabitaciones = habitacionesCollectionNewHabitaciones.getIdHotel();
                    habitacionesCollectionNewHabitaciones.setIdHotel(hotel);
                    habitacionesCollectionNewHabitaciones = em.merge(habitacionesCollectionNewHabitaciones);
                    if (oldIdHotelOfHabitacionesCollectionNewHabitaciones != null && !oldIdHotelOfHabitacionesCollectionNewHabitaciones.equals(hotel)) {
                        oldIdHotelOfHabitacionesCollectionNewHabitaciones.getHabitacionesCollection().remove(habitacionesCollectionNewHabitaciones);
                        oldIdHotelOfHabitacionesCollectionNewHabitaciones = em.merge(oldIdHotelOfHabitacionesCollectionNewHabitaciones);
                    }
                }
            }
            for (Empleados empleadosCollectionOldEmpleados : empleadosCollectionOld) {
                if (!empleadosCollectionNew.contains(empleadosCollectionOldEmpleados)) {
                    empleadosCollectionOldEmpleados.setIdHotel(null);
                    empleadosCollectionOldEmpleados = em.merge(empleadosCollectionOldEmpleados);
                }
            }
            for (Empleados empleadosCollectionNewEmpleados : empleadosCollectionNew) {
                if (!empleadosCollectionOld.contains(empleadosCollectionNewEmpleados)) {
                    Hotel oldIdHotelOfEmpleadosCollectionNewEmpleados = empleadosCollectionNewEmpleados.getIdHotel();
                    empleadosCollectionNewEmpleados.setIdHotel(hotel);
                    empleadosCollectionNewEmpleados = em.merge(empleadosCollectionNewEmpleados);
                    if (oldIdHotelOfEmpleadosCollectionNewEmpleados != null && !oldIdHotelOfEmpleadosCollectionNewEmpleados.equals(hotel)) {
                        oldIdHotelOfEmpleadosCollectionNewEmpleados.getEmpleadosCollection().remove(empleadosCollectionNewEmpleados);
                        oldIdHotelOfEmpleadosCollectionNewEmpleados = em.merge(oldIdHotelOfEmpleadosCollectionNewEmpleados);
                    }
                }
            }
            for (Reservaciones reservacionesCollectionOldReservaciones : reservacionesCollectionOld) {
                if (!reservacionesCollectionNew.contains(reservacionesCollectionOldReservaciones)) {
                    reservacionesCollectionOldReservaciones.setIdHotel(null);
                    reservacionesCollectionOldReservaciones = em.merge(reservacionesCollectionOldReservaciones);
                }
            }
            for (Reservaciones reservacionesCollectionNewReservaciones : reservacionesCollectionNew) {
                if (!reservacionesCollectionOld.contains(reservacionesCollectionNewReservaciones)) {
                    Hotel oldIdHotelOfReservacionesCollectionNewReservaciones = reservacionesCollectionNewReservaciones.getIdHotel();
                    reservacionesCollectionNewReservaciones.setIdHotel(hotel);
                    reservacionesCollectionNewReservaciones = em.merge(reservacionesCollectionNewReservaciones);
                    if (oldIdHotelOfReservacionesCollectionNewReservaciones != null && !oldIdHotelOfReservacionesCollectionNewReservaciones.equals(hotel)) {
                        oldIdHotelOfReservacionesCollectionNewReservaciones.getReservacionesCollection().remove(reservacionesCollectionNewReservaciones);
                        oldIdHotelOfReservacionesCollectionNewReservaciones = em.merge(oldIdHotelOfReservacionesCollectionNewReservaciones);
                    }
                }
            }
            for (Facturas facturasCollectionOldFacturas : facturasCollectionOld) {
                if (!facturasCollectionNew.contains(facturasCollectionOldFacturas)) {
                    facturasCollectionOldFacturas.setIdHotel(null);
                    facturasCollectionOldFacturas = em.merge(facturasCollectionOldFacturas);
                }
            }
            for (Facturas facturasCollectionNewFacturas : facturasCollectionNew) {
                if (!facturasCollectionOld.contains(facturasCollectionNewFacturas)) {
                    Hotel oldIdHotelOfFacturasCollectionNewFacturas = facturasCollectionNewFacturas.getIdHotel();
                    facturasCollectionNewFacturas.setIdHotel(hotel);
                    facturasCollectionNewFacturas = em.merge(facturasCollectionNewFacturas);
                    if (oldIdHotelOfFacturasCollectionNewFacturas != null && !oldIdHotelOfFacturasCollectionNewFacturas.equals(hotel)) {
                        oldIdHotelOfFacturasCollectionNewFacturas.getFacturasCollection().remove(facturasCollectionNewFacturas);
                        oldIdHotelOfFacturasCollectionNewFacturas = em.merge(oldIdHotelOfFacturasCollectionNewFacturas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = hotel.getIdHotel();
                if (findHotel(id) == null) {
                    throw new NonexistentEntityException("The hotel with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Hotel hotel;
            try {
                hotel = em.getReference(Hotel.class, id);
                hotel.getIdHotel();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The hotel with id " + id + " no longer exists.", enfe);
            }
            Collection<Habitaciones> habitacionesCollection = hotel.getHabitacionesCollection();
            for (Habitaciones habitacionesCollectionHabitaciones : habitacionesCollection) {
                habitacionesCollectionHabitaciones.setIdHotel(null);
                habitacionesCollectionHabitaciones = em.merge(habitacionesCollectionHabitaciones);
            }
            Collection<Empleados> empleadosCollection = hotel.getEmpleadosCollection();
            for (Empleados empleadosCollectionEmpleados : empleadosCollection) {
                empleadosCollectionEmpleados.setIdHotel(null);
                empleadosCollectionEmpleados = em.merge(empleadosCollectionEmpleados);
            }
            Collection<Reservaciones> reservacionesCollection = hotel.getReservacionesCollection();
            for (Reservaciones reservacionesCollectionReservaciones : reservacionesCollection) {
                reservacionesCollectionReservaciones.setIdHotel(null);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
            }
            Collection<Facturas> facturasCollection = hotel.getFacturasCollection();
            for (Facturas facturasCollectionFacturas : facturasCollection) {
                facturasCollectionFacturas.setIdHotel(null);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
            }
            em.remove(hotel);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Hotel> findHotelEntities() {
        return findHotelEntities(true, -1, -1);
    }

    public List<Hotel> findHotelEntities(int maxResults, int firstResult) {
        return findHotelEntities(false, maxResults, firstResult);
    }

    private List<Hotel> findHotelEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Hotel.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Hotel findHotel(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Hotel.class, id);
        } finally {
            em.close();
        }
    }

    public int getHotelCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Hotel> rt = cq.from(Hotel.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
