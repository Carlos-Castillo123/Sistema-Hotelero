/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JPAControllers;

import EntityClases.CategoriaHabitacion;
import EntityClases.Habitaciones;
import JPAControllers.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Usser_401
 */
public class CategoriaHabitacionJpaController implements Serializable {

    public CategoriaHabitacionJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CategoriaHabitacion categoriaHabitacion) {
        if (categoriaHabitacion.getHabitacionesCollection() == null) {
            categoriaHabitacion.setHabitacionesCollection(new ArrayList<Habitaciones>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Habitaciones> attachedHabitacionesCollection = new ArrayList<Habitaciones>();
            for (Habitaciones habitacionesCollectionHabitacionesToAttach : categoriaHabitacion.getHabitacionesCollection()) {
                habitacionesCollectionHabitacionesToAttach = em.getReference(habitacionesCollectionHabitacionesToAttach.getClass(), habitacionesCollectionHabitacionesToAttach.getIdHabitacion());
                attachedHabitacionesCollection.add(habitacionesCollectionHabitacionesToAttach);
            }
            categoriaHabitacion.setHabitacionesCollection(attachedHabitacionesCollection);
            em.persist(categoriaHabitacion);
            for (Habitaciones habitacionesCollectionHabitaciones : categoriaHabitacion.getHabitacionesCollection()) {
                CategoriaHabitacion oldIdCategoriaOfHabitacionesCollectionHabitaciones = habitacionesCollectionHabitaciones.getIdCategoria();
                habitacionesCollectionHabitaciones.setIdCategoria(categoriaHabitacion);
                habitacionesCollectionHabitaciones = em.merge(habitacionesCollectionHabitaciones);
                if (oldIdCategoriaOfHabitacionesCollectionHabitaciones != null) {
                    oldIdCategoriaOfHabitacionesCollectionHabitaciones.getHabitacionesCollection().remove(habitacionesCollectionHabitaciones);
                    oldIdCategoriaOfHabitacionesCollectionHabitaciones = em.merge(oldIdCategoriaOfHabitacionesCollectionHabitaciones);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CategoriaHabitacion categoriaHabitacion) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoriaHabitacion persistentCategoriaHabitacion = em.find(CategoriaHabitacion.class, categoriaHabitacion.getIdCategoria());
            Collection<Habitaciones> habitacionesCollectionOld = persistentCategoriaHabitacion.getHabitacionesCollection();
            Collection<Habitaciones> habitacionesCollectionNew = categoriaHabitacion.getHabitacionesCollection();
            Collection<Habitaciones> attachedHabitacionesCollectionNew = new ArrayList<Habitaciones>();
            for (Habitaciones habitacionesCollectionNewHabitacionesToAttach : habitacionesCollectionNew) {
                habitacionesCollectionNewHabitacionesToAttach = em.getReference(habitacionesCollectionNewHabitacionesToAttach.getClass(), habitacionesCollectionNewHabitacionesToAttach.getIdHabitacion());
                attachedHabitacionesCollectionNew.add(habitacionesCollectionNewHabitacionesToAttach);
            }
            habitacionesCollectionNew = attachedHabitacionesCollectionNew;
            categoriaHabitacion.setHabitacionesCollection(habitacionesCollectionNew);
            categoriaHabitacion = em.merge(categoriaHabitacion);
            for (Habitaciones habitacionesCollectionOldHabitaciones : habitacionesCollectionOld) {
                if (!habitacionesCollectionNew.contains(habitacionesCollectionOldHabitaciones)) {
                    habitacionesCollectionOldHabitaciones.setIdCategoria(null);
                    habitacionesCollectionOldHabitaciones = em.merge(habitacionesCollectionOldHabitaciones);
                }
            }
            for (Habitaciones habitacionesCollectionNewHabitaciones : habitacionesCollectionNew) {
                if (!habitacionesCollectionOld.contains(habitacionesCollectionNewHabitaciones)) {
                    CategoriaHabitacion oldIdCategoriaOfHabitacionesCollectionNewHabitaciones = habitacionesCollectionNewHabitaciones.getIdCategoria();
                    habitacionesCollectionNewHabitaciones.setIdCategoria(categoriaHabitacion);
                    habitacionesCollectionNewHabitaciones = em.merge(habitacionesCollectionNewHabitaciones);
                    if (oldIdCategoriaOfHabitacionesCollectionNewHabitaciones != null && !oldIdCategoriaOfHabitacionesCollectionNewHabitaciones.equals(categoriaHabitacion)) {
                        oldIdCategoriaOfHabitacionesCollectionNewHabitaciones.getHabitacionesCollection().remove(habitacionesCollectionNewHabitaciones);
                        oldIdCategoriaOfHabitacionesCollectionNewHabitaciones = em.merge(oldIdCategoriaOfHabitacionesCollectionNewHabitaciones);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = categoriaHabitacion.getIdCategoria();
                if (findCategoriaHabitacion(id) == null) {
                    throw new NonexistentEntityException("The categoriaHabitacion with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoriaHabitacion categoriaHabitacion;
            try {
                categoriaHabitacion = em.getReference(CategoriaHabitacion.class, id);
                categoriaHabitacion.getIdCategoria();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The categoriaHabitacion with id " + id + " no longer exists.", enfe);
            }
            Collection<Habitaciones> habitacionesCollection = categoriaHabitacion.getHabitacionesCollection();
            for (Habitaciones habitacionesCollectionHabitaciones : habitacionesCollection) {
                habitacionesCollectionHabitaciones.setIdCategoria(null);
                habitacionesCollectionHabitaciones = em.merge(habitacionesCollectionHabitaciones);
            }
            em.remove(categoriaHabitacion);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CategoriaHabitacion> findCategoriaHabitacionEntities() {
        return findCategoriaHabitacionEntities(true, -1, -1);
    }

    public List<CategoriaHabitacion> findCategoriaHabitacionEntities(int maxResults, int firstResult) {
        return findCategoriaHabitacionEntities(false, maxResults, firstResult);
    }

    private List<CategoriaHabitacion> findCategoriaHabitacionEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CategoriaHabitacion.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CategoriaHabitacion findCategoriaHabitacion(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CategoriaHabitacion.class, id);
        } finally {
            em.close();
        }
    }

    public int getCategoriaHabitacionCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CategoriaHabitacion> rt = cq.from(CategoriaHabitacion.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
