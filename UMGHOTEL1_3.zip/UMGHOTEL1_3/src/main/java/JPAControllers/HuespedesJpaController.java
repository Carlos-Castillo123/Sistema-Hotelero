/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JPAControllers;

import EntityClases.Huespedes;
import EntityClases.Reservaciones;
import EntityClases.Usuarios;
import JPAControllers.exceptions.NonexistentEntityException;
import JPAControllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Usser_401
 */
public class HuespedesJpaController implements Serializable {

    public HuespedesJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Huespedes huespedes) throws PreexistingEntityException, Exception {
        if (huespedes.getReservacionesCollection() == null) {
            huespedes.setReservacionesCollection(new ArrayList<Reservaciones>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios usuario = huespedes.getUsuario();
            if (usuario != null) {
                usuario = em.getReference(usuario.getClass(), usuario.getUsuario());
                huespedes.setUsuario(usuario);
            }
            Collection<Reservaciones> attachedReservacionesCollection = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionReservacionesToAttach : huespedes.getReservacionesCollection()) {
                reservacionesCollectionReservacionesToAttach = em.getReference(reservacionesCollectionReservacionesToAttach.getClass(), reservacionesCollectionReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollection.add(reservacionesCollectionReservacionesToAttach);
            }
            huespedes.setReservacionesCollection(attachedReservacionesCollection);
            em.persist(huespedes);
            if (usuario != null) {
                usuario.getHuespedesCollection().add(huespedes);
                usuario = em.merge(usuario);
            }
            for (Reservaciones reservacionesCollectionReservaciones : huespedes.getReservacionesCollection()) {
                Huespedes oldIdentificacionOfReservacionesCollectionReservaciones = reservacionesCollectionReservaciones.getIdentificacion();
                reservacionesCollectionReservaciones.setIdentificacion(huespedes);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
                if (oldIdentificacionOfReservacionesCollectionReservaciones != null) {
                    oldIdentificacionOfReservacionesCollectionReservaciones.getReservacionesCollection().remove(reservacionesCollectionReservaciones);
                    oldIdentificacionOfReservacionesCollectionReservaciones = em.merge(oldIdentificacionOfReservacionesCollectionReservaciones);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findHuespedes(huespedes.getIdentificacion()) != null) {
                throw new PreexistingEntityException("Huespedes " + huespedes + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Huespedes huespedes) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Huespedes persistentHuespedes = em.find(Huespedes.class, huespedes.getIdentificacion());
            Usuarios usuarioOld = persistentHuespedes.getUsuario();
            Usuarios usuarioNew = huespedes.getUsuario();
            Collection<Reservaciones> reservacionesCollectionOld = persistentHuespedes.getReservacionesCollection();
            Collection<Reservaciones> reservacionesCollectionNew = huespedes.getReservacionesCollection();
            if (usuarioNew != null) {
                usuarioNew = em.getReference(usuarioNew.getClass(), usuarioNew.getUsuario());
                huespedes.setUsuario(usuarioNew);
            }
            Collection<Reservaciones> attachedReservacionesCollectionNew = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionNewReservacionesToAttach : reservacionesCollectionNew) {
                reservacionesCollectionNewReservacionesToAttach = em.getReference(reservacionesCollectionNewReservacionesToAttach.getClass(), reservacionesCollectionNewReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollectionNew.add(reservacionesCollectionNewReservacionesToAttach);
            }
            reservacionesCollectionNew = attachedReservacionesCollectionNew;
            huespedes.setReservacionesCollection(reservacionesCollectionNew);
            huespedes = em.merge(huespedes);
            if (usuarioOld != null && !usuarioOld.equals(usuarioNew)) {
                usuarioOld.getHuespedesCollection().remove(huespedes);
                usuarioOld = em.merge(usuarioOld);
            }
            if (usuarioNew != null && !usuarioNew.equals(usuarioOld)) {
                usuarioNew.getHuespedesCollection().add(huespedes);
                usuarioNew = em.merge(usuarioNew);
            }
            for (Reservaciones reservacionesCollectionOldReservaciones : reservacionesCollectionOld) {
                if (!reservacionesCollectionNew.contains(reservacionesCollectionOldReservaciones)) {
                    reservacionesCollectionOldReservaciones.setIdentificacion(null);
                    reservacionesCollectionOldReservaciones = em.merge(reservacionesCollectionOldReservaciones);
                }
            }
            for (Reservaciones reservacionesCollectionNewReservaciones : reservacionesCollectionNew) {
                if (!reservacionesCollectionOld.contains(reservacionesCollectionNewReservaciones)) {
                    Huespedes oldIdentificacionOfReservacionesCollectionNewReservaciones = reservacionesCollectionNewReservaciones.getIdentificacion();
                    reservacionesCollectionNewReservaciones.setIdentificacion(huespedes);
                    reservacionesCollectionNewReservaciones = em.merge(reservacionesCollectionNewReservaciones);
                    if (oldIdentificacionOfReservacionesCollectionNewReservaciones != null && !oldIdentificacionOfReservacionesCollectionNewReservaciones.equals(huespedes)) {
                        oldIdentificacionOfReservacionesCollectionNewReservaciones.getReservacionesCollection().remove(reservacionesCollectionNewReservaciones);
                        oldIdentificacionOfReservacionesCollectionNewReservaciones = em.merge(oldIdentificacionOfReservacionesCollectionNewReservaciones);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = huespedes.getIdentificacion();
                if (findHuespedes(id) == null) {
                    throw new NonexistentEntityException("The huespedes with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Huespedes huespedes;
            try {
                huespedes = em.getReference(Huespedes.class, id);
                huespedes.getIdentificacion();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The huespedes with id " + id + " no longer exists.", enfe);
            }
            Usuarios usuario = huespedes.getUsuario();
            if (usuario != null) {
                usuario.getHuespedesCollection().remove(huespedes);
                usuario = em.merge(usuario);
            }
            Collection<Reservaciones> reservacionesCollection = huespedes.getReservacionesCollection();
            for (Reservaciones reservacionesCollectionReservaciones : reservacionesCollection) {
                reservacionesCollectionReservaciones.setIdentificacion(null);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
            }
            em.remove(huespedes);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Huespedes> findHuespedesEntities() {
        return findHuespedesEntities(true, -1, -1);
    }

    public List<Huespedes> findHuespedesEntities(int maxResults, int firstResult) {
        return findHuespedesEntities(false, maxResults, firstResult);
    }

    private List<Huespedes> findHuespedesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Huespedes.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Huespedes findHuespedes(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Huespedes.class, id);
        } finally {
            em.close();
        }
    }

    public int getHuespedesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Huespedes> rt = cq.from(Huespedes.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
