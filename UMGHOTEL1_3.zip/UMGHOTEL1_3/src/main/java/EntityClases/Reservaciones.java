/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EntityClases;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Usser_401
 */
@Entity
@Table(name = "RESERVACIONES", catalog = "UMGHOTEL", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "Reservaciones.findAll", query = "SELECT r FROM Reservaciones r")})
public class Reservaciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_reservacion", nullable = false)
    private Integer idReservacion;
    @Basic(optional = false)
    @Column(name = "fecha_reserva", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaReserva;
    @Basic(optional = false)
    @Column(name = "fecha_checkin", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaCheckin;
    @Basic(optional = false)
    @Column(name = "hora_checkin", nullable = false)
    @Temporal(TemporalType.TIME)
    private Date horaCheckin;
    @Basic(optional = false)
    @Column(name = "cantidad_noches", nullable = false)
    private int cantidadNoches;
    @Basic(optional = false)
    @Column(name = "disponible", nullable = false)
    private boolean disponible;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "total_reservacion", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalReservacion;
    @OneToMany(mappedBy = "idReservacion")
    private Collection<DetalleFactura> detalleFacturaCollection;
    @JoinColumn(name = "id_habitacion", referencedColumnName = "id_habitacion")
    @ManyToOne
    private Habitaciones idHabitacion;
    @JoinColumn(name = "id_hotel", referencedColumnName = "id_hotel")
    @ManyToOne
    private Hotel idHotel;
    @JoinColumn(name = "identificacion", referencedColumnName = "identificacion")
    @ManyToOne
    private Huespedes identificacion;
    @OneToMany(mappedBy = "idReservacion")
    private Collection<Checkout> checkoutCollection;
    @OneToMany(mappedBy = "idReservacion")
    private Collection<Facturas> facturasCollection;

    public Reservaciones() {
    }

    public Reservaciones(Integer idReservacion) {
        this.idReservacion = idReservacion;
    }

    public Reservaciones(Integer idReservacion, Date fechaReserva, Date fechaCheckin, Date horaCheckin, int cantidadNoches, boolean disponible, BigDecimal totalReservacion) {
        this.idReservacion = idReservacion;
        this.fechaReserva = fechaReserva;
        this.fechaCheckin = fechaCheckin;
        this.horaCheckin = horaCheckin;
        this.cantidadNoches = cantidadNoches;
        this.disponible = disponible;
        this.totalReservacion = totalReservacion;
    }

    public Integer getIdReservacion() {
        return idReservacion;
    }

    public void setIdReservacion(Integer idReservacion) {
        this.idReservacion = idReservacion;
    }

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public Date getFechaCheckin() {
        return fechaCheckin;
    }

    public void setFechaCheckin(Date fechaCheckin) {
        this.fechaCheckin = fechaCheckin;
    }

    public Date getHoraCheckin() {
        return horaCheckin;
    }

    public void setHoraCheckin(Date horaCheckin) {
        this.horaCheckin = horaCheckin;
    }

    public int getCantidadNoches() {
        return cantidadNoches;
    }

    public void setCantidadNoches(int cantidadNoches) {
        this.cantidadNoches = cantidadNoches;
    }

    public boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public BigDecimal getTotalReservacion() {
        return totalReservacion;
    }

    public void setTotalReservacion(BigDecimal totalReservacion) {
        this.totalReservacion = totalReservacion;
    }

    public Collection<DetalleFactura> getDetalleFacturaCollection() {
        return detalleFacturaCollection;
    }

    public void setDetalleFacturaCollection(Collection<DetalleFactura> detalleFacturaCollection) {
        this.detalleFacturaCollection = detalleFacturaCollection;
    }

    public Habitaciones getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(Habitaciones idHabitacion) {
        this.idHabitacion = idHabitacion;
    }

    public Hotel getIdHotel() {
        return idHotel;
    }

    public void setIdHotel(Hotel idHotel) {
        this.idHotel = idHotel;
    }

    public Huespedes getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(Huespedes identificacion) {
        this.identificacion = identificacion;
    }

    public Collection<Checkout> getCheckoutCollection() {
        return checkoutCollection;
    }

    public void setCheckoutCollection(Collection<Checkout> checkoutCollection) {
        this.checkoutCollection = checkoutCollection;
    }

    public Collection<Facturas> getFacturasCollection() {
        return facturasCollection;
    }

    public void setFacturasCollection(Collection<Facturas> facturasCollection) {
        this.facturasCollection = facturasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idReservacion != null ? idReservacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservaciones)) {
            return false;
        }
        Reservaciones other = (Reservaciones) object;
        if ((this.idReservacion == null && other.idReservacion != null) || (this.idReservacion != null && !this.idReservacion.equals(other.idReservacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EntityClases.Reservaciones[ idReservacion=" + idReservacion + " ]";
    }
    
}
