/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EntityClases;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Usser_401
 */
@Entity
@Table(name = "FACTURAS", catalog = "UMGHOTEL", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "Facturas.findAll", query = "SELECT f FROM Facturas f")})
public class Facturas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_factura", nullable = false)
    private Integer idFactura;
    @Column(name = "metodo_pago", length = 255)
    private String metodoPago;
    @Basic(optional = false)
    @Column(name = "nit", nullable = false, length = 20)
    private String nit;
    @Basic(optional = false)
    @Column(name = "fecha_emision", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaEmision;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "total_pagar", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalPagar;
    @JoinColumn(name = "id_checkout", referencedColumnName = "id_checkout")
    @ManyToOne
    private Checkout idCheckout;
    @JoinColumn(name = "id_detalle", referencedColumnName = "id_detalle")
    @ManyToOne
    private DetalleFactura idDetalle;
    @JoinColumn(name = "id_hotel", referencedColumnName = "id_hotel")
    @ManyToOne
    private Hotel idHotel;
    @JoinColumn(name = "id_reservacion", referencedColumnName = "id_reservacion")
    @ManyToOne
    private Reservaciones idReservacion;

    public Facturas() {
    }

    public Facturas(Integer idFactura) {
        this.idFactura = idFactura;
    }

    public Facturas(Integer idFactura, String nit, Date fechaEmision, BigDecimal totalPagar) {
        this.idFactura = idFactura;
        this.nit = nit;
        this.fechaEmision = fechaEmision;
        this.totalPagar = totalPagar;
    }

    public Integer getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(Integer idFactura) {
        this.idFactura = idFactura;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public BigDecimal getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(BigDecimal totalPagar) {
        this.totalPagar = totalPagar;
    }

    public Checkout getIdCheckout() {
        return idCheckout;
    }

    public void setIdCheckout(Checkout idCheckout) {
        this.idCheckout = idCheckout;
    }

    public DetalleFactura getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(DetalleFactura idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Hotel getIdHotel() {
        return idHotel;
    }

    public void setIdHotel(Hotel idHotel) {
        this.idHotel = idHotel;
    }

    public Reservaciones getIdReservacion() {
        return idReservacion;
    }

    public void setIdReservacion(Reservaciones idReservacion) {
        this.idReservacion = idReservacion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFactura != null ? idFactura.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Facturas)) {
            return false;
        }
        Facturas other = (Facturas) object;
        if ((this.idFactura == null && other.idFactura != null) || (this.idFactura != null && !this.idFactura.equals(other.idFactura))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EntityClases.Facturas[ idFactura=" + idFactura + " ]";
    }
    
}
