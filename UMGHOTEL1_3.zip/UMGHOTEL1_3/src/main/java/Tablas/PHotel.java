/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.Hotel;
import JPAControllers.HotelJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PHotel {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);

            try {
                em = emf.createEntityManager();
                Hotel CH = new Hotel();
                System.out.println("Ingresando nuevo Hotel:");
                System.out.println("-----------------------");

                System.out.println("Ingresa Nombre:");
                String nombre = esc.nextLine();
                CH.setNombre(nombre);

                System.out.println("Ingresa Dirección:");
                String direccion = esc.nextLine();
                CH.setDireccion(direccion);

                System.out.println("Ingresa Teléfono:");
                int telefono = esc.nextInt();
                CH.setTelefono(telefono);

                em.getTransaction().begin();
                em.persist(CH); // Persistir el objeto
                em.getTransaction().commit();
                System.out.println("Hotel creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Hotel> CHarray = new ArrayList<>();
            HotelJpaController ac = new HotelJpaController(emf);

            try {
                em = emf.createEntityManager();
                CHarray = ac.findHotelEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }

            // Mostrar los datos de hoteles
            for (Hotel al : CHarray) {
                System.out.println("-------------------");
                System.out.println("Id_Hotel: " + al.getIdHotel());
                System.out.println("Nombre: " + al.getNombre());
                System.out.println("Dirección: " + al.getDireccion());
                System.out.println("Teléfono: " + al.getTelefono());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Hotel");
            System.out.println("¿Qué hotel deseas modificar? (Ingresa el Id_Hotel)");
            id = esc.nextInt();
            esc.nextLine(); // Limpiar buffer

            HotelJpaController ac = new HotelJpaController(emf);
            Hotel hotelParaModificar = ac.findHotel(id);

            if (hotelParaModificar != null) {
                System.out.println("Hotel encontrado: " + hotelParaModificar.getNombre());

                System.out.println("Ingresa nuevo Nombre:");
                String nuevoNombre = esc.nextLine();
                hotelParaModificar.setNombre(nuevoNombre);

                System.out.println("Ingresa nueva Dirección:");
                String nuevaDireccion = esc.nextLine();
                hotelParaModificar.setDireccion(nuevaDireccion);

                System.out.println("Ingresa nuevo Teléfono:");
                int nuevoTelefono = esc.nextInt();
                hotelParaModificar.setTelefono(nuevoTelefono);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(hotelParaModificar); // Actualizar el hotel
                    em.getTransaction().commit();
                    System.out.println("Hotel actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Hotel no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Eliminando Hotel");
            System.out.println("¿Qué hotel deseas eliminar? (Ingresa el Id_Hotel)");
            id = esc.nextInt();

            HotelJpaController ac = new HotelJpaController(emf);
            Hotel hotelParaEliminar = ac.findHotel(id);

            if (hotelParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(hotelParaEliminar)); // Eliminar el hotel
                    em.getTransaction().commit();
                    System.out.println("Hotel eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Hotel no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nuevo Hotel");
            System.out.println("2. Ver Hoteles Existentes");
            System.out.println("3. Editar Hotel");
            System.out.println("4. Eliminar Hotel");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
