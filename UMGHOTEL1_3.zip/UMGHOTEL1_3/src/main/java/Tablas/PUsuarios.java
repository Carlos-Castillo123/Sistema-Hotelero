/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;


import EntityClases.Usuarios;
import JPAControllers.UsuariosJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PUsuarios {
    public static class Metodos{
    public void CREATE(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Usuarios CH = new Usuarios();
            System.out.println("Ingresando nuevo Usuario:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Contrasena:");
            String idcat = esc.nextLine();
            CH.setContasena(idcat);

            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    }
    
    public void READ(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        List<Usuarios> CHarray = new ArrayList<>();
        UsuariosJpaController ac = new UsuariosJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findUsuariosEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Usuarios al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Usuario: " + al.getUsuario());
            System.out.println("Contrasena: " + al.getContasena());
        }   
        System.out.println("-------------------");
        }
    public void UPDATE(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        int op;
        System.out.println("Modificando Usuarios");
        System.out.println("Que Usuario Deseas Modificar? (Ingresa el No.Usser)");
        op = esc.nextInt(); // Aquí 'op' es el identificador del usuario
    
        List<Usuarios> CHarray = new ArrayList<>();
        UsuariosJpaController ac = new UsuariosJpaController(emf);
    
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findUsuariosEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }
    
        // Buscar el usuario a modificar
        Usuarios usuarioParaModificar = null;
        for (Usuarios usuario : CHarray) {
            if (usuario.getUsuario().equals(op)) {
                usuarioParaModificar = usuario;
                break;
            }
        }
    
        // Verificar si encontramos el usuario
        if (usuarioParaModificar != null) {
            System.out.println("Usuario encontrado: " + usuarioParaModificar.getUsuario());
            System.out.println("Contrasena actual: " + usuarioParaModificar.getContasena());

            // Modificar los datos
            System.out.println("Ingresa nueva contrasena:");
            String nuevaContrasena = esc.next();
            usuarioParaModificar.setContasena(nuevaContrasena);  // Cambiamos la contraseña
        
            // Persistimos los cambios
            try {
                em = emf.createEntityManager(); // Abrimos una nueva sesión de EntityManager
                em.getTransaction().begin();  // Iniciamos la transacción
                em.merge(usuarioParaModificar); // Hacemos el merge para actualizar el usuario
                em.getTransaction().commit();  // Confirmamos los cambios
                System.out.println("Usuario actualizado exitosamente.");
            } catch (Exception e) {
                e.printStackTrace();
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();  // Revertimos los cambios si ocurre un error
                }
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerramos el EntityManager después de la transacción
                }
            }
        } else {
            System.out.println("Usuario no encontrado.");
            }
        }
    public void DELETE() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        int op;
        System.out.println("Borrando Usuario");
        System.out.println("¿Qué Usuario Deseas Borrar? (Ingresa el No.Usser)");
        op = esc.nextInt();  // Aquí 'op' es el identificador del usuario a borrar
    
        List<Usuarios> CHarray = new ArrayList<>();
        UsuariosJpaController ac = new UsuariosJpaController(emf);
    
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findUsuariosEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }
    
        // Buscar el usuario a borrar
        Usuarios usuarioParaBorrar = null;
        for (Usuarios usuario : CHarray) {
            if (usuario.getUsuario().equals(op)) {
                usuarioParaBorrar = usuario;
                break;
            }
        }
    
        // Verificar si encontramos el usuario
        if (usuarioParaBorrar != null) {
            System.out.println("Usuario encontrado: " + usuarioParaBorrar.getUsuario());
            System.out.println("Contrasena: " + usuarioParaBorrar.getContasena());

            // Eliminar el usuario
            try {
                em = emf.createEntityManager(); // Abrimos una nueva sesión de EntityManager
                em.getTransaction().begin();  // Iniciamos la transacción
                em.remove(em.merge(usuarioParaBorrar));  // Eliminamos el usuario
                em.getTransaction().commit();  // Confirmamos los cambios
                System.out.println("Usuario borrado exitosamente.");
            } catch (Exception e) {
                e.printStackTrace();
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();  // Revertimos los cambios si ocurre un error
                }
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerramos el EntityManager después de la transacción
                }
            }
        } else {
            System.out.println("Usuario no encontrado.");
            }
        }

    }
    
    //MAIN
    
    public static void main(String[] args) {
        try{
            System.out.println("Escribe que deseas realizar");
            System.out.println("1. Crear Nuevo Usuario");
            System.out.println("2. Ver Usuarios Existentes");
            System.out.println("3. Editar Usuarios Existentes");
            System.out.println("4. Eliminar Usuarios Existentes");
            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos m1 = new Metodos();
            switch (op){
                case 1:
                    m1.CREATE();
                        break;
                case 2:
                    m1.READ();
                        break;
                case 3:
                    m1.UPDATE();
                        break;
                case 4:
                    m1.DELETE();
                        break;
            }
        }catch(Exception e){
            System.out.println("Hubo un error en el proceso, intentalo nuevamente");
        }
    }
}
