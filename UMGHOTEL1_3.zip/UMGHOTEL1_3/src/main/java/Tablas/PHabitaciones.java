/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.CategoriaHabitacion;
import EntityClases.Habitaciones;
import EntityClases.Hotel;
import JPAControllers.HabitacionesJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PHabitaciones {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);

            try {
                em = emf.createEntityManager();
                Habitaciones hab = new Habitaciones();
                System.out.println("Ingresando nueva Habitación:");
                System.out.println("-----------------------");

                System.out.println("Ingresa ID Hotel:");
                int idhotel = esc.nextInt();
                Hotel hotelid = em.find(Hotel.class, idhotel);
                hab.setIdHotel(hotelid);

                System.out.println("Ingresa ID Categoría:");
                int idcat = esc.nextInt();
                CategoriaHabitacion catid = em.find(CategoriaHabitacion.class, idcat);
                hab.setIdCategoria(catid);

                esc.nextLine(); // Limpiar buffer
                System.out.println("Ingresa No. Habitacion:");
                String NHabi = esc.nextLine();
                hab.setNoHabitacion(NHabi);

                System.out.println("Ingresa Precio Por Noche:");
                Double Precio = esc.nextDouble();
                hab.setPrecioNoche(Precio);

                em.getTransaction().begin();
                em.persist(hab); // Persistir el objeto
                em.getTransaction().commit();
                System.out.println("Habitación creada con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Habitaciones> habArray = new ArrayList<>();
            HabitacionesJpaController ac = new HabitacionesJpaController(emf);

            try {
                em = emf.createEntityManager();
                habArray = ac.findHabitacionesEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }

            // Mostrar los datos de habitaciones
            for (Habitaciones hab : habArray) {
                System.out.println("-------------------");
                System.out.println("Id_Habitacion: " + hab.getIdHabitacion());
                System.out.println("Id_Hotel: " + hab.getIdHotel().getIdHotel());
                System.out.println("Id_Categoria: " + hab.getIdCategoria().getIdCategoria());
                System.out.println("No. de Habitacion: " + hab.getNoHabitacion());
                System.out.println("Precio por noche: " + hab.getPrecioNoche());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Habitación");
            System.out.println("¿Qué habitación deseas modificar? (Ingresa el Id_Habitacion)");
            id = esc.nextInt();
            esc.nextLine(); // Limpiar buffer

            HabitacionesJpaController ac = new HabitacionesJpaController(emf);
            Habitaciones habitacionParaModificar = ac.findHabitaciones(id);

            if (habitacionParaModificar != null) {
                System.out.println("Habitación encontrada: " + habitacionParaModificar.getNoHabitacion());

                System.out.println("Ingresa nuevo No. de Habitación:");
                String nuevoNoHabitacion = esc.nextLine();
                habitacionParaModificar.setNoHabitacion(nuevoNoHabitacion);

                System.out.println("Ingresa nuevo Precio Por Noche:");
                Double nuevoPrecio = esc.nextDouble();
                habitacionParaModificar.setPrecioNoche(nuevoPrecio);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(habitacionParaModificar); // Actualizar la habitación
                    em.getTransaction().commit();
                    System.out.println("Habitación actualizada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Habitación no encontrada.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Eliminando Habitación");
            System.out.println("¿Qué habitación deseas eliminar? (Ingresa el Id_Habitacion)");
            id = esc.nextInt();

            HabitacionesJpaController ac = new HabitacionesJpaController(emf);
            Habitaciones habitacionParaEliminar = ac.findHabitaciones(id);

            if (habitacionParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(habitacionParaEliminar)); // Eliminar la habitación
                    em.getTransaction().commit();
                    System.out.println("Habitación eliminada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Habitación no encontrada.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nueva Habitación");
            System.out.println("2. Ver Habitaciones Existentes");
            System.out.println("3. Editar Habitación");
            System.out.println("4. Eliminar Habitación");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
