/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.Checkout;
import EntityClases.DetalleFactura;
import EntityClases.Reservaciones;
import JPAControllers.CheckoutJpaController;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PCheckOut {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            Checkout checkout = new Checkout();

            try {
                em = emf.createEntityManager(); // Crear EntityManager
                System.out.println("Ingresando nuevo CheckOut:");
                System.out.println("-----------------------");
                
                System.out.println("Ingresa Id reservacion:");
                int idReservacion = esc.nextInt();
                Reservaciones reservacion = em.find(Reservaciones.class, idReservacion);
                checkout.setIdReservacion(reservacion);
                
                System.out.println("Ingresa Id Detalles:");
                int idDetalle = esc.nextInt();
                DetalleFactura detalleFactura = em.find(DetalleFactura.class, idDetalle);
                checkout.setIdDetalle(detalleFactura);
                esc.nextLine();
                
                System.out.println("Ingresa Fecha Checkout (yyyy-MM-dd):");
                String fechaCheckout = esc.nextLine();
                SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = formatoFecha.parse(fechaCheckout);
                checkout.setFechaCheckout(fecha);
                
                System.out.println("Ingresa Hora Checkout (HH:mm:ss):");
                String horaCheckout = esc.nextLine();
                SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss");
                Date hora = formatoHora.parse(horaCheckout);
                checkout.setHoraCheckout(hora);
                
                System.out.println("Ingresa Metodo de Pago:");
                String metodoPago = esc.nextLine();
                checkout.setMetodoPago(metodoPago);
                
                System.out.println("Total a Pagar: " + detalleFactura.getPrecioTotal());
                checkout.setTotalPagar(detalleFactura.getPrecioTotal());
                
                // Inicia transacción
                em.getTransaction().begin();
                em.persist(checkout); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("CheckOut creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Checkout> checkoutList = new ArrayList<>();
            CheckoutJpaController checkoutController = new CheckoutJpaController(emf);

            try {
                em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
                checkoutList = checkoutController.findCheckoutEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar todos los datos
            for (Checkout checkout : checkoutList) {
                System.out.println("-------------------");
                System.out.println("ID Checkout: " + checkout.getIdCheckout());
                System.out.println("ID Reservacion: " + checkout.getIdReservacion().getIdReservacion());
                System.out.println("ID Detalle: " + checkout.getIdDetalle().getIdDetalle());
                SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
                System.out.println("Fecha Checkout: " + formatoFecha.format(checkout.getFechaCheckout()));
                SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss");
                System.out.println("Hora Checkout: " + formatoHora.format(checkout.getHoraCheckout()));
                System.out.println("Metodo de Pago: " + checkout.getMetodoPago());
                System.out.println("Total a Pagar: " + checkout.getTotalPagar());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() throws ParseException {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando CheckOut");
            System.out.println("¿Qué CheckOut deseas modificar? (Ingresa el ID de CheckOut)");
            id = esc.nextInt();

            CheckoutJpaController checkoutController = new CheckoutJpaController(emf);
            Checkout checkoutParaModificar = checkoutController.findCheckout(id);

            if (checkoutParaModificar != null) {
                System.out.println("CheckOut encontrado: " + checkoutParaModificar.getIdCheckout());

                // Aquí puedes modificar los atributos que deseas actualizar
                System.out.println("Ingresa nueva Fecha Checkout (yyyy-MM-dd):");
                String nuevaFecha = esc.next();
                SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = formatoFecha.parse(nuevaFecha);
                checkoutParaModificar.setFechaCheckout(fecha);

                System.out.println("Ingresa nueva Hora Checkout (HH:mm:ss):");
                String nuevaHora = esc.next();
                SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss");
                Date hora = formatoHora.parse(nuevaHora);
                checkoutParaModificar.setHoraCheckout(hora);

                System.out.println("Ingresa nuevo Método de Pago:");
                String nuevoMetodoPago = esc.next();
                checkoutParaModificar.setMetodoPago(nuevoMetodoPago);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(checkoutParaModificar); // Actualizar el checkout
                    em.getTransaction().commit();
                    System.out.println("CheckOut actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("CheckOut no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int idCheckout;

            System.out.println("Eliminando CheckOut");
            System.out.println("¿Qué CheckOut deseas eliminar? (Ingresa el ID de CheckOut)");
            idCheckout = esc.nextInt();

            CheckoutJpaController checkoutController = new CheckoutJpaController(emf);
            Checkout checkoutParaEliminar = checkoutController.findCheckout(idCheckout);

            if (checkoutParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(checkoutParaEliminar)); // Eliminar el checkout
                    em.getTransaction().commit();
                    System.out.println("CheckOut eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("CheckOut no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nuevo CheckOut");
            System.out.println("2. Ver CheckOuts Existentes");
            System.out.println("3. Editar CheckOut");
            System.out.println("4. Eliminar CheckOut");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
