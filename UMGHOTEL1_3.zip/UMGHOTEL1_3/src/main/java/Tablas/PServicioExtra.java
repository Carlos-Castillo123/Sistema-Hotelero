/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.ServicioExtra;
import JPAControllers.ServicioExtraJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PServicioExtra {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            ServicioExtra servicioExtra = new ServicioExtra();

            try {
                em = emf.createEntityManager(); // Crear EntityManager
                System.out.println("Ingresando nuevo Servicio Extra:");
                System.out.println("-----------------------");
                
                System.out.println("Ingresa Descripción:");
                String descripcion = esc.nextLine();
                servicioExtra.setDescripcion(descripcion);
                
                System.out.println("Ingresa Cantidad:");
                int cantidad = esc.nextInt();
                servicioExtra.setCantidad(cantidad);
                
                System.out.println("Ingresa Precio:");
                Double precio = esc.nextDouble();
                servicioExtra.setPrecio(precio);
                
                Double totalServicio = cantidad * precio;
                System.out.println("Total Servicio: " + totalServicio);
                servicioExtra.setTotalServicio(totalServicio);
                
                // Inicia transacción
                em.getTransaction().begin();
                em.persist(servicioExtra); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("Servicio Extra creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<ServicioExtra> servicioExtraList = new ArrayList<>();
            ServicioExtraJpaController servicioExtraController = new ServicioExtraJpaController(emf);

            try {
                em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
                servicioExtraList = servicioExtraController.findServicioExtraEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar todos los datos
            for (ServicioExtra servicio : servicioExtraList) {
                System.out.println("-------------------");
                System.out.println("ID Servicio: " + servicio.getIdServicio());
                System.out.println("Descripción: " + servicio.getDescripcion());
                System.out.println("Cantidad: " + servicio.getCantidad());
                System.out.println("Precio: " + servicio.getPrecio());
                System.out.println("Total: " + servicio.getTotalServicio());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Servicio Extra");
            System.out.println("¿Qué servicio deseas modificar? (Ingresa el ID de Servicio)");
            id = esc.nextInt();

            ServicioExtraJpaController servicioExtraController = new ServicioExtraJpaController(emf);
            ServicioExtra servicioParaModificar = servicioExtraController.findServicioExtra(id);

            if (servicioParaModificar != null) {
                System.out.println("Servicio encontrado: " + servicioParaModificar.getIdServicio());

                // Aquí puedes modificar los atributos que deseas actualizar
                System.out.println("Ingresa nueva Descripción:");
                String nuevaDescripcion = esc.next();
                servicioParaModificar.setDescripcion(nuevaDescripcion);
                
                System.out.println("Ingresa nueva Cantidad:");
                int nuevaCantidad = esc.nextInt();
                servicioParaModificar.setCantidad(nuevaCantidad);

                System.out.println("Ingresa nuevo Precio:");
                Double nuevoPrecio = esc.nextDouble();
                servicioParaModificar.setPrecio(nuevoPrecio);
                
                // Recalcular total
                Double nuevoTotal = nuevaCantidad * nuevoPrecio;
                servicioParaModificar.setTotalServicio(nuevoTotal);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(servicioParaModificar); // Actualizar el servicio
                    em.getTransaction().commit();
                    System.out.println("Servicio Extra actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Servicio no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int idServicio;

            System.out.println("Eliminando Servicio Extra");
            System.out.println("¿Qué servicio deseas eliminar? (Ingresa el ID de Servicio)");
            idServicio = esc.nextInt();

            ServicioExtraJpaController servicioExtraController = new ServicioExtraJpaController(emf);
            ServicioExtra servicioParaEliminar = servicioExtraController.findServicioExtra(idServicio);

            if (servicioParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(servicioParaEliminar)); // Eliminar el servicio
                    em.getTransaction().commit();
                    System.out.println("Servicio Extra eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Servicio no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nuevo Servicio Extra");
            System.out.println("2. Ver Servicios Extras Existentes");
            System.out.println("3. Editar Servicio Extra");
            System.out.println("4. Eliminar Servicio Extra");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
