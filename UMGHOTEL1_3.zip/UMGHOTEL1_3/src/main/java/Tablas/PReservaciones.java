/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;


import EntityClases.Habitaciones;
import EntityClases.Hotel;
import EntityClases.Huespedes;
import EntityClases.Reservaciones;
import JPAControllers.ReservacionesJpaController;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PReservaciones {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            Reservaciones CH = new Reservaciones();

            try {
                em = emf.createEntityManager(); // Crear EntityManager
                System.out.println("Ingresando nueva Reservacion:");
                System.out.println("-----------------------");
                
                System.out.println("Ingresa ID Hotel:");
                int idhotel = esc.nextInt();
                Hotel hotelid = em.find(Hotel.class, idhotel);
                CH.setIdHotel(hotelid);

                System.out.println("Ingresa ID Habitacion:");
                int idhab = esc.nextInt();
                Habitaciones habitacion = em.find(Habitaciones.class, idhab);
                CH.setIdHabitacion(habitacion);

                esc.nextLine(); // Capturar el salto de línea
                System.out.println("Ingresa identificacion:");
                String id = esc.nextLine();
                Huespedes ide = em.find(Huespedes.class, id);
                CH.setIdentificacion(ide);

                System.out.println("Ingresa Fecha Reserva (yyyy-MM-dd):");
                String fechaR = esc.nextLine();
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = formato.parse(fechaR);
                CH.setFechaReserva(fecha);

                System.out.println("Ingresa Fecha CheckIn (yyyy-MM-dd):");
                String fechaIn = esc.nextLine();
                Date fechasIn = formato.parse(fechaIn);
                CH.setFechaCheckin(fechasIn);

                System.out.println("Ingresa Hora CheckIn (hh:mm:ss):");
                String HoraIn = esc.nextLine();
                SimpleDateFormat formatoo = new SimpleDateFormat("HH:mm:ss");
                Date HorasIn = formatoo.parse(HoraIn);
                CH.setHoraCheckin(HorasIn);

                System.out.println("Ingresa Cantidad Noches:");
                int noches = esc.nextInt();
                CH.setCantidadNoches(noches);

                System.out.println("Disponible (true/false):");
                Boolean dis = esc.nextBoolean();
                CH.setDisponible(dis);
                Double PrecioRoom = habitacion.getPrecioNoche();
                Double tot = PrecioRoom * noches;
                System.out.println("Total Reservacion: " + tot);
                BigDecimal pagar = BigDecimal.valueOf(tot);
                CH.setTotalReservacion(pagar);

                // Inicia transacción
                em.getTransaction().begin();
                em.persist(CH); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("Reservación creada con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Reservaciones> CHarray = new ArrayList<>();
            ReservacionesJpaController ac = new ReservacionesJpaController(emf);

            try {
                em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
                CHarray = ac.findReservacionesEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar todos los datos
            for (Reservaciones al : CHarray) {
                System.out.println("-------------------");
                System.out.println("ID Reservacion: " + al.getIdReservacion());
                System.out.println("ID Hotel: " + al.getIdHotel().getIdHotel());
                System.out.println("ID Habitacion: " + al.getIdHabitacion().getIdHabitacion());
                System.out.println("Identificacion: " + al.getIdentificacion().getIdentificacion());

                SimpleDateFormat formatoRes = new SimpleDateFormat("yyyy-MM-dd");
                System.out.println("Fecha Reserva: " + formatoRes.format(al.getFechaReserva()));

                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                System.out.println("Fecha CheckIn: " + formato.format(al.getFechaCheckin()));

                SimpleDateFormat formatos = new SimpleDateFormat("HH:mm:ss");
                System.out.println("Hora CheckIn: " + formatos.format(al.getHoraCheckin()));

                System.out.println("Cantidad Noches: " + al.getCantidadNoches());
                System.out.println("Cantidad Disponible: " + al.getDisponible());
                System.out.println("Cantidad Total: " + al.getTotalReservacion());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Reservación");
            System.out.println("¿Qué reservación deseas modificar? (Ingresa el ID de Reservación)");
            id = esc.nextInt();

            ReservacionesJpaController ac = new ReservacionesJpaController(emf);
            Reservaciones reservacionParaModificar = ac.findReservaciones(id);

            if (reservacionParaModificar != null) {
                System.out.println("Reservación encontrada: " + reservacionParaModificar.getIdReservacion());

                // Aquí puedes modificar los atributos que deseas actualizar
                System.out.println("Ingresa nueva Cantidad Noches:");
                int nuevasNoches = esc.nextInt();
                reservacionParaModificar.setCantidadNoches(nuevasNoches);

                // Repetir para otros campos que quieras modificar

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(reservacionParaModificar); // Actualizar la reservación
                    em.getTransaction().commit();
                    System.out.println("Reservación actualizada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Reservación no encontrada.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int idReservacion;

            System.out.println("Eliminando Reservación");
            System.out.println("¿Qué reservación deseas eliminar? (Ingresa el ID de Reservación)");
            idReservacion = esc.nextInt();

            ReservacionesJpaController ac = new ReservacionesJpaController(emf);
            Reservaciones reservacionParaEliminar = ac.findReservaciones(idReservacion);

            if (reservacionParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(reservacionParaEliminar)); // Eliminar la reservación
                    em.getTransaction().commit();
                    System.out.println("Reservación eliminada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Reservación no encontrada.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nueva Reservación");
            System.out.println("2. Ver Reservaciones Existentes");
            System.out.println("3. Editar Reservación");
            System.out.println("4. Eliminar Reservación");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}

