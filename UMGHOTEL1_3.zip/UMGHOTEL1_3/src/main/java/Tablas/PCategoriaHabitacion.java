/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.CategoriaHabitacion;
import JPAControllers.CategoriaHabitacionJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PCategoriaHabitacion {
    public static class Metodos {
        
        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);

            try {
                System.out.println("Ingresando nueva Categoria de Habitacion:");
                System.out.println("-----------------------");
                em = emf.createEntityManager();
                CategoriaHabitacion CH = new CategoriaHabitacion();
                
                System.out.println("Ingresa Descripcion:");
                String descripcion = esc.nextLine();
                CH.setDescripcion(descripcion);

                System.out.println("Ingresa cantidad de Camas:");
                int camas = esc.nextInt();
                CH.setCantidadCamas(camas);

                em.getTransaction().begin();
                em.persist(CH); // Persistir objeto
                em.getTransaction().commit(); // Confirmar transacción
                System.out.println("Categoría de Habitación creada con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Rollback en caso de error
                }
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<CategoriaHabitacion> CHarray = new ArrayList<>();
            CategoriaHabitacionJpaController ac = new CategoriaHabitacionJpaController(emf);

            try {
                em = emf.createEntityManager();
                CHarray = ac.findCategoriaHabitacionEntities();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }

            for (CategoriaHabitacion al : CHarray) {
                System.out.println("-------------------");
                System.out.println("Id_CategoriaHabitacion: " + al.getIdCategoria());
                System.out.println("Descripcion: " + al.getDescripcion());
                System.out.println("Camas: " + al.getCantidadCamas());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Categoria de Habitacion");
            System.out.println("¿Qué Categoria deseas modificar? (Ingresa el Id_CategoriaHabitacion)");
            id = esc.nextInt(); 
            esc.nextLine(); // Limpiar buffer

            CategoriaHabitacionJpaController ac = new CategoriaHabitacionJpaController(emf);
            CategoriaHabitacion categoriaParaModificar = ac.findCategoriaHabitacion(id);

            if (categoriaParaModificar != null) {
                System.out.println("Categoria encontrada: " + categoriaParaModificar.getDescripcion());
                System.out.println("Cantidad de Camas actual: " + categoriaParaModificar.getCantidadCamas());

                System.out.println("Ingresa nueva Descripción:");
                String nuevaDescripcion = esc.nextLine();
                categoriaParaModificar.setDescripcion(nuevaDescripcion);

                System.out.println("Ingresa nueva cantidad de Camas:");
                int nuevasCamas = esc.nextInt();
                categoriaParaModificar.setCantidadCamas(nuevasCamas);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(categoriaParaModificar); // Actualizar
                    em.getTransaction().commit();
                    System.out.println("Categoria de Habitación actualizada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Categoria no encontrada.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Eliminando Categoria de Habitacion");
            System.out.println("¿Qué Categoria deseas eliminar? (Ingresa el Id_CategoriaHabitacion)");
            id = esc.nextInt(); 

            CategoriaHabitacionJpaController ac = new CategoriaHabitacionJpaController(emf);
            CategoriaHabitacion categoriaParaBorrar = ac.findCategoriaHabitacion(id);

            if (categoriaParaBorrar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(categoriaParaBorrar)); // Eliminar
                    em.getTransaction().commit();
                    System.out.println("Categoria de Habitación eliminada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Categoria no encontrada.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe que deseas realizar");
            System.out.println("1. Crear Nueva Categoria de Habitacion");
            System.out.println("2. Ver Categorias Existentes");
            System.out.println("3. Editar Categoria de Habitacion");
            System.out.println("4. Eliminar Categoria de Habitacion");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
