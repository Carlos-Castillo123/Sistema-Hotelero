/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.Empleados;
import EntityClases.Hotel;
import JPAControllers.EmpleadosJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PEmpleados {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);

            try {
                em = emf.createEntityManager();
                Empleados emp = new Empleados();
                System.out.println("Ingresando nuevo Empleado:");
                System.out.println("-----------------------");

                System.out.println("Ingresa ID Hotel:");
                int idhotel = esc.nextInt();
                Hotel hotelid = em.find(Hotel.class, idhotel);
                emp.setIdHotel(hotelid);

                esc.nextLine(); // Limpiar buffer
                System.out.println("Ingresa Nombres:");
                String names = esc.nextLine();
                emp.setNombres(names);

                System.out.println("Ingresa Apellidos:");
                String apellidos = esc.nextLine();
                emp.setApellidos(apellidos);

                System.out.println("Ingresa Email:");
                String email = esc.nextLine();
                emp.setEmail(email);

                System.out.println("Ingresa Telefono:");
                String tel = esc.nextLine();
                emp.setTelefono(tel);

                System.out.println("Ingresa Area:");
                String area = esc.nextLine();
                emp.setArea(area);

                em.getTransaction().begin();
                em.persist(emp); // Persistir el objeto
                em.getTransaction().commit();
                System.out.println("Empleado creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Empleados> empArray = new ArrayList<>();
            EmpleadosJpaController ac = new EmpleadosJpaController(emf);

            try {
                em = emf.createEntityManager();
                empArray = ac.findEmpleadosEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (em != null && em.isOpen()) {
                    em.close();
                }
            }

            // Mostrar los datos de empleados
            for (Empleados emp : empArray) {
                System.out.println("-------------------");
                System.out.println("Id_Empleado: " + emp.getIdEmpleado());
                System.out.println("Id_Hotel: " + emp.getIdHotel().getIdHotel());
                System.out.println("Nombre: " + emp.getNombres());
                System.out.println("Apellidos: " + emp.getApellidos());
                System.out.println("Email: " + emp.getEmail());
                System.out.println("Telefono: " + emp.getTelefono());
                System.out.println("Area: " + emp.getArea());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Empleado");
            System.out.println("¿Qué empleado deseas modificar? (Ingresa el Id_Empleado)");
            id = esc.nextInt();
            esc.nextLine(); // Limpiar buffer

            EmpleadosJpaController ac = new EmpleadosJpaController(emf);
            Empleados empleadoParaModificar = ac.findEmpleados(id);

            if (empleadoParaModificar != null) {
                System.out.println("Empleado encontrado: " + empleadoParaModificar.getNombres());

                System.out.println("Ingresa nuevo Nombres:");
                String nuevosNombres = esc.nextLine();
                empleadoParaModificar.setNombres(nuevosNombres);

                System.out.println("Ingresa nuevo Apellidos:");
                String nuevosApellidos = esc.nextLine();
                empleadoParaModificar.setApellidos(nuevosApellidos);

                System.out.println("Ingresa nuevo Email:");
                String nuevoEmail = esc.nextLine();
                empleadoParaModificar.setEmail(nuevoEmail);

                System.out.println("Ingresa nuevo Telefono:");
                String nuevoTelefono = esc.nextLine();
                empleadoParaModificar.setTelefono(nuevoTelefono);

                System.out.println("Ingresa nueva Area:");
                String nuevaArea = esc.nextLine();
                empleadoParaModificar.setArea(nuevaArea);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(empleadoParaModificar); // Actualizar el empleado
                    em.getTransaction().commit();
                    System.out.println("Empleado actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Empleado no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Eliminando Empleado");
            System.out.println("¿Qué empleado deseas eliminar? (Ingresa el Id_Empleado)");
            id = esc.nextInt();

            EmpleadosJpaController ac = new EmpleadosJpaController(emf);
            Empleados empleadoParaEliminar = ac.findEmpleados(id);

            if (empleadoParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(empleadoParaEliminar)); // Eliminar el empleado
                    em.getTransaction().commit();
                    System.out.println("Empleado eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Empleado no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe que deseas realizar:");
            System.out.println("1. Crear Nuevo Empleado");
            System.out.println("2. Ver Empleados Existentes");
            System.out.println("3. Editar Empleado");
            System.out.println("4. Eliminar Empleado");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}

