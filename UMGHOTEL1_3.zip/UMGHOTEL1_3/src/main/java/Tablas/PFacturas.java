/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.Checkout;
import EntityClases.DetalleFactura;
import EntityClases.Facturas;
import EntityClases.Hotel;
import EntityClases.Reservaciones;
import JPAControllers.FacturasJpaController;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PFacturas {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            Facturas factura = new Facturas();

            try {
                em = emf.createEntityManager(); // Crear EntityManager
                System.out.println("Ingresando nueva Factura:");
                System.out.println("-----------------------");

                System.out.println("Ingresa Id Hotel:");
                int ires = esc.nextInt();
                Hotel hotel = em.find(Hotel.class, ires);
                factura.setIdHotel(hotel);

                System.out.println("Ingresa Id reservacion:");
                int reserva = esc.nextInt();
                Reservaciones reservacion = em.find(Reservaciones.class, reserva);
                factura.setIdReservacion(reservacion);

                System.out.println("Ingresa Id Detalles:");
                int iser = esc.nextInt();
                DetalleFactura detalle = em.find(DetalleFactura.class, iser);
                factura.setIdDetalle(detalle);

                System.out.println("Ingresa Id Checkout:");
                int check = esc.nextInt();
                Checkout checkout = em.find(Checkout.class, check);
                factura.setIdCheckout(checkout);
                esc.nextLine();

                System.out.println("Metodo de Pago: " + checkout.getMetodoPago());
                factura.setMetodoPago(checkout.getMetodoPago());

                System.out.println("Ingresa NIT:");
                String nit = esc.nextLine();
                factura.setNit(nit);

                System.out.println("Ingresa Fecha Emision(yyyy-MM-dd):");
                String fechaEmisionStr = esc.nextLine();
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fechaEmision = formato.parse(fechaEmisionStr);
                factura.setFechaEmision(fechaEmision);

                System.out.println("Total a Pagar: " + checkout.getTotalPagar());
                BigDecimal totalPagar = BigDecimal.valueOf(checkout.getTotalPagar());
                factura.setTotalPagar(totalPagar);

                // Inicia transacción
                em.getTransaction().begin();
                em.persist(factura); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("Factura creada con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Facturas> facturaList = new ArrayList<>();
            FacturasJpaController facturaController = new FacturasJpaController(emf);

            try {
                em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
                facturaList = facturaController.findFacturasEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar todos los datos
            for (Facturas factura : facturaList) {
                System.out.println("-------------------");
                System.out.println("ID Factura: " + factura.getIdFactura());
                System.out.println("ID Hotel: " + factura.getIdHotel().getIdHotel());
                System.out.println("ID Reservacion: " + factura.getIdReservacion().getIdReservacion());
                System.out.println("ID Detalle: " + factura.getIdDetalle().getIdDetalle());
                System.out.println("ID Checkout: " + factura.getIdCheckout().getIdCheckout());
                System.out.println("Metodo de Pago: " + factura.getMetodoPago());
                System.out.println("NIT: " + factura.getNit());
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                System.out.println("Fecha Emision: " + formato.format(factura.getFechaEmision()));
                System.out.println("Total a Pagar: " + factura.getTotalPagar());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Factura");
            System.out.println("¿Qué Factura deseas modificar? (Ingresa el ID de Factura)");
            id = esc.nextInt();

            FacturasJpaController facturaController = new FacturasJpaController(emf);
            Facturas facturaParaModificar = facturaController.findFacturas(id);

            if (facturaParaModificar != null) {
                System.out.println("Factura encontrada: " + facturaParaModificar.getIdFactura());

                // Aquí puedes modificar los atributos que deseas actualizar
                System.out.println("Ingresa nueva Cantidad a Pagar:");
                BigDecimal nuevoTotalPagar = esc.nextBigDecimal();
                facturaParaModificar.setTotalPagar(nuevoTotalPagar);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(facturaParaModificar); // Actualizar la factura
                    em.getTransaction().commit();
                    System.out.println("Factura actualizada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Factura no encontrada.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int idFactura;

            System.out.println("Eliminando Factura");
            System.out.println("¿Qué Factura deseas eliminar? (Ingresa el ID de Factura)");
            idFactura = esc.nextInt();

            FacturasJpaController facturaController = new FacturasJpaController(emf);
            Facturas facturaParaEliminar = facturaController.findFacturas(idFactura);

            if (facturaParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(facturaParaEliminar)); // Eliminar la factura
                    em.getTransaction().commit();
                    System.out.println("Factura eliminada con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Factura no encontrada.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nueva Factura");
            System.out.println("2. Ver Facturas Existentes");
            System.out.println("3. Editar Factura");
            System.out.println("4. Eliminar Factura");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
