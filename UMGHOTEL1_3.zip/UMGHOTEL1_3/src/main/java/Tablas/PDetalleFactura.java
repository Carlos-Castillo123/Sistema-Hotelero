/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.DetalleFactura;
import EntityClases.Reservaciones;
import EntityClases.ServicioExtra;
import JPAControllers.DetalleFacturaJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PDetalleFactura {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            DetalleFactura detalleFactura = new DetalleFactura();

            try {
                em = emf.createEntityManager(); // Crear EntityManager
                System.out.println("Ingresando nuevo Detalle-Factura:");
                System.out.println("-----------------------");
                
                System.out.println("Ingresa Id reservacion:");
                int ires = esc.nextInt();
                Reservaciones irs = em.find(Reservaciones.class, ires);
                detalleFactura.setIdReservacion(irs);
                detalleFactura.setDescripcion(irs.getIdHabitacion().getIdCategoria().getDescripcion());
                detalleFactura.setPrecioUnitario(irs.getIdHabitacion().getPrecioNoche());
                detalleFactura.setCantidad(irs.getCantidadNoches());
                detalleFactura.setPrecioTotal(irs.getCantidadNoches() * irs.getIdHabitacion().getPrecioNoche());
                
                System.out.println("Ingresa Id Servicio:");
                int iser = esc.nextInt();
                ServicioExtra ids = em.find(ServicioExtra.class, iser);
                detalleFactura.setIdServicio(ids);
                detalleFactura.setNombre(ids.getDescripcion());
                
                System.out.println("Ingresa Cantidad:");
                int cant = esc.nextInt();
                detalleFactura.setCantidad(cant);
                
                // Inicia transacción
                em.getTransaction().begin();
                em.persist(detalleFactura); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("Detalle-Factura creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<DetalleFactura> detalleFacturaList = new ArrayList<>();
            DetalleFacturaJpaController detalleFacturaController = new DetalleFacturaJpaController(emf);

            try {
                em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
                detalleFacturaList = detalleFacturaController.findDetalleFacturaEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar todos los datos
            for (DetalleFactura detalle : detalleFacturaList) {
                System.out.println("-------------------");
                System.out.println("ID Detalle: " + detalle.getIdDetalle());
                System.out.println("ID Reservacion: " + detalle.getIdReservacion().getIdReservacion());
                System.out.println("ID Servicio: " + detalle.getIdServicio().getIdServicio());
                System.out.println("Nombre: " + detalle.getNombre());
                System.out.println("Descripcion: " + detalle.getDescripcion());
                System.out.println("Cantidad: " + detalle.getCantidad());
                System.out.println("Precio Unitario: " + detalle.getPrecioUnitario());
                System.out.println("Precio Total: " + detalle.getPrecioTotal());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Detalle-Factura");
            System.out.println("¿Qué Detalle-Factura deseas modificar? (Ingresa el ID de Detalle)");
            id = esc.nextInt();

            DetalleFacturaJpaController detalleFacturaController = new DetalleFacturaJpaController(emf);
            DetalleFactura detalleFacturaParaModificar = detalleFacturaController.findDetalleFactura(id);

            if (detalleFacturaParaModificar != null) {
                System.out.println("Detalle-Factura encontrado: " + detalleFacturaParaModificar.getIdDetalle());

                // Aquí puedes modificar los atributos que deseas actualizar
                System.out.println("Ingresa nueva Cantidad:");
                int nuevaCantidad = esc.nextInt();
                detalleFacturaParaModificar.setCantidad(nuevaCantidad);
                
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(detalleFacturaParaModificar); // Actualizar el detalleFactura
                    em.getTransaction().commit();
                    System.out.println("Detalle-Factura actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Detalle-Factura no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int idDetalle;

            System.out.println("Eliminando Detalle-Factura");
            System.out.println("¿Qué Detalle-Factura deseas eliminar? (Ingresa el ID de Detalle)");
            idDetalle = esc.nextInt();

            DetalleFacturaJpaController detalleFacturaController = new DetalleFacturaJpaController(emf);
            DetalleFactura detalleFacturaParaEliminar = detalleFacturaController.findDetalleFactura(idDetalle);

            if (detalleFacturaParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(detalleFacturaParaEliminar)); // Eliminar el detalleFactura
                    em.getTransaction().commit();
                    System.out.println("Detalle-Factura eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Detalle-Factura no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nuevo Detalle-Factura");
            System.out.println("2. Ver Detalles-Factura Existentes");
            System.out.println("3. Editar Detalle-Factura");
            System.out.println("4. Eliminar Detalle-Factura");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
