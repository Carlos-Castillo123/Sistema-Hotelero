/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.Huespedes;
import EntityClases.Usuarios;
import JPAControllers.HuespedesJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PHuespedes {

    public static class Metodos {

        // Método CREATE
        public void CREATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);

            try {
                em = emf.createEntityManager();
                Huespedes huesped = new Huespedes();
                System.out.println("Ingresando nuevo Huesped:");
                System.out.println("-----------------------");

                System.out.println("Ingresa Identificación:");
                String idp = esc.nextLine();
                huesped.setIdentificacion(idp);

                System.out.println("Ingresa Usuario:");
                int usser = esc.nextInt();
                Usuarios usu = em.find(Usuarios.class, usser);
                huesped.setUsuario(usu);
                esc.nextLine(); // Limpiar el buffer

                System.out.println("Ingresa Nombres:");
                String nombres = esc.nextLine();
                huesped.setNombres(nombres);

                System.out.println("Ingresa Apellidos:");
                String apellidos = esc.nextLine();
                huesped.setApellidos(apellidos);

                System.out.println("Ingresa Email:");
                String email = esc.nextLine();
                huesped.setEmail(email);

                System.out.println("Ingresa Teléfono:");
                String telefono = esc.nextLine();
                huesped.setTelefono(telefono);

                // Inicia la transacción
                em.getTransaction().begin();
                em.persist(huesped); // Persistir el objeto
                em.getTransaction().commit(); // Confirmar la transacción
                System.out.println("Huésped creado con éxito.");
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback(); // Hacer rollback si hay error
                }
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager al final
                }
            }
        }

        // Método READ
        public void READ() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            List<Huespedes> huespedesList = new ArrayList<>();
            HuespedesJpaController ac = new HuespedesJpaController(emf);

            try {
                em = emf.createEntityManager();
                huespedesList = ac.findHuespedesEntities(); // Obtener todos los registros
            } catch (Exception e) {
                e.printStackTrace(); // Imprimir traza de la excepción
            } finally {
                if (em != null && em.isOpen()) {
                    em.close(); // Cerrar el EntityManager después de la lectura
                }
            }

            // Mostrar los datos de huéspedes
            for (Huespedes huesped : huespedesList) {
                System.out.println("-------------------");
                System.out.println("Identificación: " + huesped.getIdentificacion());
                System.out.println("Usuario: " + huesped.getUsuario().getUsuario());
                System.out.println("Nombres: " + huesped.getNombres());
                System.out.println("Apellidos: " + huesped.getApellidos());
                System.out.println("Email: " + huesped.getEmail());
                System.out.println("Teléfono: " + huesped.getTelefono());
            }
            System.out.println("-------------------");
        }

        // Método UPDATE
        public void UPDATE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            int id;

            System.out.println("Modificando Huésped");
            System.out.println("¿Qué huésped deseas modificar? (Ingresa la Identificación)");
            String idHuesped = esc.nextLine();

            HuespedesJpaController ac = new HuespedesJpaController(emf);
            Huespedes huespedParaModificar = ac.findHuespedes(idHuesped);

            if (huespedParaModificar != null) {
                System.out.println("Huésped encontrado: " + huespedParaModificar.getNombres());

                System.out.println("Ingresa nuevo Nombre:");
                String nuevoNombre = esc.nextLine();
                huespedParaModificar.setNombres(nuevoNombre);

                System.out.println("Ingresa nuevos Apellidos:");
                String nuevosApellidos = esc.nextLine();
                huespedParaModificar.setApellidos(nuevosApellidos);

                System.out.println("Ingresa nuevo Email:");
                String nuevoEmail = esc.nextLine();
                huespedParaModificar.setEmail(nuevoEmail);

                System.out.println("Ingresa nuevo Teléfono:");
                String nuevoTelefono = esc.nextLine();
                huespedParaModificar.setTelefono(nuevoTelefono);

                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.merge(huespedParaModificar); // Actualizar el huésped
                    em.getTransaction().commit();
                    System.out.println("Huésped actualizado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Huésped no encontrado.");
            }
        }

        // Método DELETE
        public void DELETE() {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMGHOTEL1_3_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
            Scanner esc = new Scanner(System.in);
            String idHuesped;

            System.out.println("Eliminando Huésped");
            System.out.println("¿Qué huésped deseas eliminar? (Ingresa la Identificación)");
            idHuesped = esc.nextLine();

            HuespedesJpaController ac = new HuespedesJpaController(emf);
            Huespedes huespedParaEliminar = ac.findHuespedes(idHuesped);

            if (huespedParaEliminar != null) {
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    em.remove(em.merge(huespedParaEliminar)); // Eliminar el huésped
                    em.getTransaction().commit();
                    System.out.println("Huésped eliminado con éxito.");
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    e.printStackTrace();
                } finally {
                    if (em != null && em.isOpen()) {
                        em.close();
                    }
                }
            } else {
                System.out.println("Huésped no encontrado.");
            }
        }
    }

    // Método MAIN con menú
    public static void main(String[] args) {
        try {
            System.out.println("Escribe qué deseas realizar:");
            System.out.println("1. Crear Nuevo Huésped");
            System.out.println("2. Ver Huéspedes Existentes");
            System.out.println("3. Editar Huésped");
            System.out.println("4. Eliminar Huésped");

            Scanner esc = new Scanner(System.in);
            int op = esc.nextInt();
            Metodos metodos = new Metodos();

            switch (op) {
                case 1:
                    metodos.CREATE();
                    break;
                case 2:
                    metodos.READ();
                    break;
                case 3:
                    metodos.UPDATE();
                    break;
                case 4:
                    metodos.DELETE();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } catch (Exception e) {
            System.out.println("Hubo un error en el proceso, inténtalo nuevamente.");
        }
    }
}
