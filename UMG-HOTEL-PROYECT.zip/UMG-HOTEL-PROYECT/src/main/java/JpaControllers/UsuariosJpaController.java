/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.Huespedes;
import EntityClases.bd.Usuarios;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class UsuariosJpaController implements Serializable {

    public UsuariosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuarios usuarios) {
        if (usuarios.getHuespedesCollection() == null) {
            usuarios.setHuespedesCollection(new ArrayList<Huespedes>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Huespedes> attachedHuespedesCollection = new ArrayList<Huespedes>();
            for (Huespedes huespedesCollectionHuespedesToAttach : usuarios.getHuespedesCollection()) {
                huespedesCollectionHuespedesToAttach = em.getReference(huespedesCollectionHuespedesToAttach.getClass(), huespedesCollectionHuespedesToAttach.getIdentificacion());
                attachedHuespedesCollection.add(huespedesCollectionHuespedesToAttach);
            }
            usuarios.setHuespedesCollection(attachedHuespedesCollection);
            em.persist(usuarios);
            for (Huespedes huespedesCollectionHuespedes : usuarios.getHuespedesCollection()) {
                Usuarios oldUsuarioOfHuespedesCollectionHuespedes = huespedesCollectionHuespedes.getUsuario();
                huespedesCollectionHuespedes.setUsuario(usuarios);
                huespedesCollectionHuespedes = em.merge(huespedesCollectionHuespedes);
                if (oldUsuarioOfHuespedesCollectionHuespedes != null) {
                    oldUsuarioOfHuespedesCollectionHuespedes.getHuespedesCollection().remove(huespedesCollectionHuespedes);
                    oldUsuarioOfHuespedesCollectionHuespedes = em.merge(oldUsuarioOfHuespedesCollectionHuespedes);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuarios usuarios) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios persistentUsuarios = em.find(Usuarios.class, usuarios.getUsuario());
            Collection<Huespedes> huespedesCollectionOld = persistentUsuarios.getHuespedesCollection();
            Collection<Huespedes> huespedesCollectionNew = usuarios.getHuespedesCollection();
            Collection<Huespedes> attachedHuespedesCollectionNew = new ArrayList<Huespedes>();
            for (Huespedes huespedesCollectionNewHuespedesToAttach : huespedesCollectionNew) {
                huespedesCollectionNewHuespedesToAttach = em.getReference(huespedesCollectionNewHuespedesToAttach.getClass(), huespedesCollectionNewHuespedesToAttach.getIdentificacion());
                attachedHuespedesCollectionNew.add(huespedesCollectionNewHuespedesToAttach);
            }
            huespedesCollectionNew = attachedHuespedesCollectionNew;
            usuarios.setHuespedesCollection(huespedesCollectionNew);
            usuarios = em.merge(usuarios);
            for (Huespedes huespedesCollectionOldHuespedes : huespedesCollectionOld) {
                if (!huespedesCollectionNew.contains(huespedesCollectionOldHuespedes)) {
                    huespedesCollectionOldHuespedes.setUsuario(null);
                    huespedesCollectionOldHuespedes = em.merge(huespedesCollectionOldHuespedes);
                }
            }
            for (Huespedes huespedesCollectionNewHuespedes : huespedesCollectionNew) {
                if (!huespedesCollectionOld.contains(huespedesCollectionNewHuespedes)) {
                    Usuarios oldUsuarioOfHuespedesCollectionNewHuespedes = huespedesCollectionNewHuespedes.getUsuario();
                    huespedesCollectionNewHuespedes.setUsuario(usuarios);
                    huespedesCollectionNewHuespedes = em.merge(huespedesCollectionNewHuespedes);
                    if (oldUsuarioOfHuespedesCollectionNewHuespedes != null && !oldUsuarioOfHuespedesCollectionNewHuespedes.equals(usuarios)) {
                        oldUsuarioOfHuespedesCollectionNewHuespedes.getHuespedesCollection().remove(huespedesCollectionNewHuespedes);
                        oldUsuarioOfHuespedesCollectionNewHuespedes = em.merge(oldUsuarioOfHuespedesCollectionNewHuespedes);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuarios.getUsuario();
                if (findUsuarios(id) == null) {
                    throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios usuarios;
            try {
                usuarios = em.getReference(Usuarios.class, id);
                usuarios.getUsuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.", enfe);
            }
            Collection<Huespedes> huespedesCollection = usuarios.getHuespedesCollection();
            for (Huespedes huespedesCollectionHuespedes : huespedesCollection) {
                huespedesCollectionHuespedes.setUsuario(null);
                huespedesCollectionHuespedes = em.merge(huespedesCollectionHuespedes);
            }
            em.remove(usuarios);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuarios> findUsuariosEntities() {
        return findUsuariosEntities(true, -1, -1);
    }

    public List<Usuarios> findUsuariosEntities(int maxResults, int firstResult) {
        return findUsuariosEntities(false, maxResults, firstResult);
    }

    private List<Usuarios> findUsuariosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuarios.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuarios findUsuarios(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuarios.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuariosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuarios> rt = cq.from(Usuarios.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
