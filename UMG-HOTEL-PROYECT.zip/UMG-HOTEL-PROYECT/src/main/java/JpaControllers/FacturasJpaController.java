/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.Checkout;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.Facturas;
import EntityClases.bd.Hotel;
import EntityClases.bd.Reservaciones;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class FacturasJpaController implements Serializable {

    public FacturasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Facturas facturas) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Checkout idCheckout = facturas.getIdCheckout();
            if (idCheckout != null) {
                idCheckout = em.getReference(idCheckout.getClass(), idCheckout.getIdCheckout());
                facturas.setIdCheckout(idCheckout);
            }
            DetalleFactura idDetalle = facturas.getIdDetalle();
            if (idDetalle != null) {
                idDetalle = em.getReference(idDetalle.getClass(), idDetalle.getIdDetalle());
                facturas.setIdDetalle(idDetalle);
            }
            Hotel idHotel = facturas.getIdHotel();
            if (idHotel != null) {
                idHotel = em.getReference(idHotel.getClass(), idHotel.getIdHotel());
                facturas.setIdHotel(idHotel);
            }
            Reservaciones idReservacion = facturas.getIdReservacion();
            if (idReservacion != null) {
                idReservacion = em.getReference(idReservacion.getClass(), idReservacion.getIdReservacion());
                facturas.setIdReservacion(idReservacion);
            }
            em.persist(facturas);
            if (idCheckout != null) {
                idCheckout.getFacturasCollection().add(facturas);
                idCheckout = em.merge(idCheckout);
            }
            if (idDetalle != null) {
                idDetalle.getFacturasCollection().add(facturas);
                idDetalle = em.merge(idDetalle);
            }
            if (idHotel != null) {
                idHotel.getFacturasCollection().add(facturas);
                idHotel = em.merge(idHotel);
            }
            if (idReservacion != null) {
                idReservacion.getFacturasCollection().add(facturas);
                idReservacion = em.merge(idReservacion);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Facturas facturas) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Facturas persistentFacturas = em.find(Facturas.class, facturas.getIdFactura());
            Checkout idCheckoutOld = persistentFacturas.getIdCheckout();
            Checkout idCheckoutNew = facturas.getIdCheckout();
            DetalleFactura idDetalleOld = persistentFacturas.getIdDetalle();
            DetalleFactura idDetalleNew = facturas.getIdDetalle();
            Hotel idHotelOld = persistentFacturas.getIdHotel();
            Hotel idHotelNew = facturas.getIdHotel();
            Reservaciones idReservacionOld = persistentFacturas.getIdReservacion();
            Reservaciones idReservacionNew = facturas.getIdReservacion();
            if (idCheckoutNew != null) {
                idCheckoutNew = em.getReference(idCheckoutNew.getClass(), idCheckoutNew.getIdCheckout());
                facturas.setIdCheckout(idCheckoutNew);
            }
            if (idDetalleNew != null) {
                idDetalleNew = em.getReference(idDetalleNew.getClass(), idDetalleNew.getIdDetalle());
                facturas.setIdDetalle(idDetalleNew);
            }
            if (idHotelNew != null) {
                idHotelNew = em.getReference(idHotelNew.getClass(), idHotelNew.getIdHotel());
                facturas.setIdHotel(idHotelNew);
            }
            if (idReservacionNew != null) {
                idReservacionNew = em.getReference(idReservacionNew.getClass(), idReservacionNew.getIdReservacion());
                facturas.setIdReservacion(idReservacionNew);
            }
            facturas = em.merge(facturas);
            if (idCheckoutOld != null && !idCheckoutOld.equals(idCheckoutNew)) {
                idCheckoutOld.getFacturasCollection().remove(facturas);
                idCheckoutOld = em.merge(idCheckoutOld);
            }
            if (idCheckoutNew != null && !idCheckoutNew.equals(idCheckoutOld)) {
                idCheckoutNew.getFacturasCollection().add(facturas);
                idCheckoutNew = em.merge(idCheckoutNew);
            }
            if (idDetalleOld != null && !idDetalleOld.equals(idDetalleNew)) {
                idDetalleOld.getFacturasCollection().remove(facturas);
                idDetalleOld = em.merge(idDetalleOld);
            }
            if (idDetalleNew != null && !idDetalleNew.equals(idDetalleOld)) {
                idDetalleNew.getFacturasCollection().add(facturas);
                idDetalleNew = em.merge(idDetalleNew);
            }
            if (idHotelOld != null && !idHotelOld.equals(idHotelNew)) {
                idHotelOld.getFacturasCollection().remove(facturas);
                idHotelOld = em.merge(idHotelOld);
            }
            if (idHotelNew != null && !idHotelNew.equals(idHotelOld)) {
                idHotelNew.getFacturasCollection().add(facturas);
                idHotelNew = em.merge(idHotelNew);
            }
            if (idReservacionOld != null && !idReservacionOld.equals(idReservacionNew)) {
                idReservacionOld.getFacturasCollection().remove(facturas);
                idReservacionOld = em.merge(idReservacionOld);
            }
            if (idReservacionNew != null && !idReservacionNew.equals(idReservacionOld)) {
                idReservacionNew.getFacturasCollection().add(facturas);
                idReservacionNew = em.merge(idReservacionNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = facturas.getIdFactura();
                if (findFacturas(id) == null) {
                    throw new NonexistentEntityException("The facturas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Facturas facturas;
            try {
                facturas = em.getReference(Facturas.class, id);
                facturas.getIdFactura();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The facturas with id " + id + " no longer exists.", enfe);
            }
            Checkout idCheckout = facturas.getIdCheckout();
            if (idCheckout != null) {
                idCheckout.getFacturasCollection().remove(facturas);
                idCheckout = em.merge(idCheckout);
            }
            DetalleFactura idDetalle = facturas.getIdDetalle();
            if (idDetalle != null) {
                idDetalle.getFacturasCollection().remove(facturas);
                idDetalle = em.merge(idDetalle);
            }
            Hotel idHotel = facturas.getIdHotel();
            if (idHotel != null) {
                idHotel.getFacturasCollection().remove(facturas);
                idHotel = em.merge(idHotel);
            }
            Reservaciones idReservacion = facturas.getIdReservacion();
            if (idReservacion != null) {
                idReservacion.getFacturasCollection().remove(facturas);
                idReservacion = em.merge(idReservacion);
            }
            em.remove(facturas);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Facturas> findFacturasEntities() {
        return findFacturasEntities(true, -1, -1);
    }

    public List<Facturas> findFacturasEntities(int maxResults, int firstResult) {
        return findFacturasEntities(false, maxResults, firstResult);
    }

    private List<Facturas> findFacturasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Facturas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Facturas findFacturas(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Facturas.class, id);
        } finally {
            em.close();
        }
    }

    public int getFacturasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Facturas> rt = cq.from(Facturas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
