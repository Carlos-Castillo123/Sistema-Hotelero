/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.Habitaciones;
import EntityClases.bd.Hotel;
import EntityClases.bd.Huespedes;
import EntityClases.bd.DetalleFactura;
import java.util.ArrayList;
import java.util.Collection;
import EntityClases.bd.Checkout;
import EntityClases.bd.Facturas;
import EntityClases.bd.Reservaciones;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class ReservacionesJpaController implements Serializable {

    public ReservacionesJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Reservaciones reservaciones) {
        if (reservaciones.getDetalleFacturaCollection() == null) {
            reservaciones.setDetalleFacturaCollection(new ArrayList<DetalleFactura>());
        }
        if (reservaciones.getCheckoutCollection() == null) {
            reservaciones.setCheckoutCollection(new ArrayList<Checkout>());
        }
        if (reservaciones.getFacturasCollection() == null) {
            reservaciones.setFacturasCollection(new ArrayList<Facturas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Habitaciones idHabitacion = reservaciones.getIdHabitacion();
            if (idHabitacion != null) {
                idHabitacion = em.getReference(idHabitacion.getClass(), idHabitacion.getIdHabitacion());
                reservaciones.setIdHabitacion(idHabitacion);
            }
            Hotel idHotel = reservaciones.getIdHotel();
            if (idHotel != null) {
                idHotel = em.getReference(idHotel.getClass(), idHotel.getIdHotel());
                reservaciones.setIdHotel(idHotel);
            }
            Huespedes identificacion = reservaciones.getIdentificacion();
            if (identificacion != null) {
                identificacion = em.getReference(identificacion.getClass(), identificacion.getIdentificacion());
                reservaciones.setIdentificacion(identificacion);
            }
            Collection<DetalleFactura> attachedDetalleFacturaCollection = new ArrayList<DetalleFactura>();
            for (DetalleFactura detalleFacturaCollectionDetalleFacturaToAttach : reservaciones.getDetalleFacturaCollection()) {
                detalleFacturaCollectionDetalleFacturaToAttach = em.getReference(detalleFacturaCollectionDetalleFacturaToAttach.getClass(), detalleFacturaCollectionDetalleFacturaToAttach.getIdDetalle());
                attachedDetalleFacturaCollection.add(detalleFacturaCollectionDetalleFacturaToAttach);
            }
            reservaciones.setDetalleFacturaCollection(attachedDetalleFacturaCollection);
            Collection<Checkout> attachedCheckoutCollection = new ArrayList<Checkout>();
            for (Checkout checkoutCollectionCheckoutToAttach : reservaciones.getCheckoutCollection()) {
                checkoutCollectionCheckoutToAttach = em.getReference(checkoutCollectionCheckoutToAttach.getClass(), checkoutCollectionCheckoutToAttach.getIdCheckout());
                attachedCheckoutCollection.add(checkoutCollectionCheckoutToAttach);
            }
            reservaciones.setCheckoutCollection(attachedCheckoutCollection);
            Collection<Facturas> attachedFacturasCollection = new ArrayList<Facturas>();
            for (Facturas facturasCollectionFacturasToAttach : reservaciones.getFacturasCollection()) {
                facturasCollectionFacturasToAttach = em.getReference(facturasCollectionFacturasToAttach.getClass(), facturasCollectionFacturasToAttach.getIdFactura());
                attachedFacturasCollection.add(facturasCollectionFacturasToAttach);
            }
            reservaciones.setFacturasCollection(attachedFacturasCollection);
            em.persist(reservaciones);
            if (idHabitacion != null) {
                idHabitacion.getReservacionesCollection().add(reservaciones);
                idHabitacion = em.merge(idHabitacion);
            }
            if (idHotel != null) {
                idHotel.getReservacionesCollection().add(reservaciones);
                idHotel = em.merge(idHotel);
            }
            if (identificacion != null) {
                identificacion.getReservacionesCollection().add(reservaciones);
                identificacion = em.merge(identificacion);
            }
            for (DetalleFactura detalleFacturaCollectionDetalleFactura : reservaciones.getDetalleFacturaCollection()) {
                Reservaciones oldIdReservacionOfDetalleFacturaCollectionDetalleFactura = detalleFacturaCollectionDetalleFactura.getIdReservacion();
                detalleFacturaCollectionDetalleFactura.setIdReservacion(reservaciones);
                detalleFacturaCollectionDetalleFactura = em.merge(detalleFacturaCollectionDetalleFactura);
                if (oldIdReservacionOfDetalleFacturaCollectionDetalleFactura != null) {
                    oldIdReservacionOfDetalleFacturaCollectionDetalleFactura.getDetalleFacturaCollection().remove(detalleFacturaCollectionDetalleFactura);
                    oldIdReservacionOfDetalleFacturaCollectionDetalleFactura = em.merge(oldIdReservacionOfDetalleFacturaCollectionDetalleFactura);
                }
            }
            for (Checkout checkoutCollectionCheckout : reservaciones.getCheckoutCollection()) {
                Reservaciones oldIdReservacionOfCheckoutCollectionCheckout = checkoutCollectionCheckout.getIdReservacion();
                checkoutCollectionCheckout.setIdReservacion(reservaciones);
                checkoutCollectionCheckout = em.merge(checkoutCollectionCheckout);
                if (oldIdReservacionOfCheckoutCollectionCheckout != null) {
                    oldIdReservacionOfCheckoutCollectionCheckout.getCheckoutCollection().remove(checkoutCollectionCheckout);
                    oldIdReservacionOfCheckoutCollectionCheckout = em.merge(oldIdReservacionOfCheckoutCollectionCheckout);
                }
            }
            for (Facturas facturasCollectionFacturas : reservaciones.getFacturasCollection()) {
                Reservaciones oldIdReservacionOfFacturasCollectionFacturas = facturasCollectionFacturas.getIdReservacion();
                facturasCollectionFacturas.setIdReservacion(reservaciones);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
                if (oldIdReservacionOfFacturasCollectionFacturas != null) {
                    oldIdReservacionOfFacturasCollectionFacturas.getFacturasCollection().remove(facturasCollectionFacturas);
                    oldIdReservacionOfFacturasCollectionFacturas = em.merge(oldIdReservacionOfFacturasCollectionFacturas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Reservaciones reservaciones) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Reservaciones persistentReservaciones = em.find(Reservaciones.class, reservaciones.getIdReservacion());
            Habitaciones idHabitacionOld = persistentReservaciones.getIdHabitacion();
            Habitaciones idHabitacionNew = reservaciones.getIdHabitacion();
            Hotel idHotelOld = persistentReservaciones.getIdHotel();
            Hotel idHotelNew = reservaciones.getIdHotel();
            Huespedes identificacionOld = persistentReservaciones.getIdentificacion();
            Huespedes identificacionNew = reservaciones.getIdentificacion();
            Collection<DetalleFactura> detalleFacturaCollectionOld = persistentReservaciones.getDetalleFacturaCollection();
            Collection<DetalleFactura> detalleFacturaCollectionNew = reservaciones.getDetalleFacturaCollection();
            Collection<Checkout> checkoutCollectionOld = persistentReservaciones.getCheckoutCollection();
            Collection<Checkout> checkoutCollectionNew = reservaciones.getCheckoutCollection();
            Collection<Facturas> facturasCollectionOld = persistentReservaciones.getFacturasCollection();
            Collection<Facturas> facturasCollectionNew = reservaciones.getFacturasCollection();
            if (idHabitacionNew != null) {
                idHabitacionNew = em.getReference(idHabitacionNew.getClass(), idHabitacionNew.getIdHabitacion());
                reservaciones.setIdHabitacion(idHabitacionNew);
            }
            if (idHotelNew != null) {
                idHotelNew = em.getReference(idHotelNew.getClass(), idHotelNew.getIdHotel());
                reservaciones.setIdHotel(idHotelNew);
            }
            if (identificacionNew != null) {
                identificacionNew = em.getReference(identificacionNew.getClass(), identificacionNew.getIdentificacion());
                reservaciones.setIdentificacion(identificacionNew);
            }
            Collection<DetalleFactura> attachedDetalleFacturaCollectionNew = new ArrayList<DetalleFactura>();
            for (DetalleFactura detalleFacturaCollectionNewDetalleFacturaToAttach : detalleFacturaCollectionNew) {
                detalleFacturaCollectionNewDetalleFacturaToAttach = em.getReference(detalleFacturaCollectionNewDetalleFacturaToAttach.getClass(), detalleFacturaCollectionNewDetalleFacturaToAttach.getIdDetalle());
                attachedDetalleFacturaCollectionNew.add(detalleFacturaCollectionNewDetalleFacturaToAttach);
            }
            detalleFacturaCollectionNew = attachedDetalleFacturaCollectionNew;
            reservaciones.setDetalleFacturaCollection(detalleFacturaCollectionNew);
            Collection<Checkout> attachedCheckoutCollectionNew = new ArrayList<Checkout>();
            for (Checkout checkoutCollectionNewCheckoutToAttach : checkoutCollectionNew) {
                checkoutCollectionNewCheckoutToAttach = em.getReference(checkoutCollectionNewCheckoutToAttach.getClass(), checkoutCollectionNewCheckoutToAttach.getIdCheckout());
                attachedCheckoutCollectionNew.add(checkoutCollectionNewCheckoutToAttach);
            }
            checkoutCollectionNew = attachedCheckoutCollectionNew;
            reservaciones.setCheckoutCollection(checkoutCollectionNew);
            Collection<Facturas> attachedFacturasCollectionNew = new ArrayList<Facturas>();
            for (Facturas facturasCollectionNewFacturasToAttach : facturasCollectionNew) {
                facturasCollectionNewFacturasToAttach = em.getReference(facturasCollectionNewFacturasToAttach.getClass(), facturasCollectionNewFacturasToAttach.getIdFactura());
                attachedFacturasCollectionNew.add(facturasCollectionNewFacturasToAttach);
            }
            facturasCollectionNew = attachedFacturasCollectionNew;
            reservaciones.setFacturasCollection(facturasCollectionNew);
            reservaciones = em.merge(reservaciones);
            if (idHabitacionOld != null && !idHabitacionOld.equals(idHabitacionNew)) {
                idHabitacionOld.getReservacionesCollection().remove(reservaciones);
                idHabitacionOld = em.merge(idHabitacionOld);
            }
            if (idHabitacionNew != null && !idHabitacionNew.equals(idHabitacionOld)) {
                idHabitacionNew.getReservacionesCollection().add(reservaciones);
                idHabitacionNew = em.merge(idHabitacionNew);
            }
            if (idHotelOld != null && !idHotelOld.equals(idHotelNew)) {
                idHotelOld.getReservacionesCollection().remove(reservaciones);
                idHotelOld = em.merge(idHotelOld);
            }
            if (idHotelNew != null && !idHotelNew.equals(idHotelOld)) {
                idHotelNew.getReservacionesCollection().add(reservaciones);
                idHotelNew = em.merge(idHotelNew);
            }
            if (identificacionOld != null && !identificacionOld.equals(identificacionNew)) {
                identificacionOld.getReservacionesCollection().remove(reservaciones);
                identificacionOld = em.merge(identificacionOld);
            }
            if (identificacionNew != null && !identificacionNew.equals(identificacionOld)) {
                identificacionNew.getReservacionesCollection().add(reservaciones);
                identificacionNew = em.merge(identificacionNew);
            }
            for (DetalleFactura detalleFacturaCollectionOldDetalleFactura : detalleFacturaCollectionOld) {
                if (!detalleFacturaCollectionNew.contains(detalleFacturaCollectionOldDetalleFactura)) {
                    detalleFacturaCollectionOldDetalleFactura.setIdReservacion(null);
                    detalleFacturaCollectionOldDetalleFactura = em.merge(detalleFacturaCollectionOldDetalleFactura);
                }
            }
            for (DetalleFactura detalleFacturaCollectionNewDetalleFactura : detalleFacturaCollectionNew) {
                if (!detalleFacturaCollectionOld.contains(detalleFacturaCollectionNewDetalleFactura)) {
                    Reservaciones oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura = detalleFacturaCollectionNewDetalleFactura.getIdReservacion();
                    detalleFacturaCollectionNewDetalleFactura.setIdReservacion(reservaciones);
                    detalleFacturaCollectionNewDetalleFactura = em.merge(detalleFacturaCollectionNewDetalleFactura);
                    if (oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura != null && !oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura.equals(reservaciones)) {
                        oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura.getDetalleFacturaCollection().remove(detalleFacturaCollectionNewDetalleFactura);
                        oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura = em.merge(oldIdReservacionOfDetalleFacturaCollectionNewDetalleFactura);
                    }
                }
            }
            for (Checkout checkoutCollectionOldCheckout : checkoutCollectionOld) {
                if (!checkoutCollectionNew.contains(checkoutCollectionOldCheckout)) {
                    checkoutCollectionOldCheckout.setIdReservacion(null);
                    checkoutCollectionOldCheckout = em.merge(checkoutCollectionOldCheckout);
                }
            }
            for (Checkout checkoutCollectionNewCheckout : checkoutCollectionNew) {
                if (!checkoutCollectionOld.contains(checkoutCollectionNewCheckout)) {
                    Reservaciones oldIdReservacionOfCheckoutCollectionNewCheckout = checkoutCollectionNewCheckout.getIdReservacion();
                    checkoutCollectionNewCheckout.setIdReservacion(reservaciones);
                    checkoutCollectionNewCheckout = em.merge(checkoutCollectionNewCheckout);
                    if (oldIdReservacionOfCheckoutCollectionNewCheckout != null && !oldIdReservacionOfCheckoutCollectionNewCheckout.equals(reservaciones)) {
                        oldIdReservacionOfCheckoutCollectionNewCheckout.getCheckoutCollection().remove(checkoutCollectionNewCheckout);
                        oldIdReservacionOfCheckoutCollectionNewCheckout = em.merge(oldIdReservacionOfCheckoutCollectionNewCheckout);
                    }
                }
            }
            for (Facturas facturasCollectionOldFacturas : facturasCollectionOld) {
                if (!facturasCollectionNew.contains(facturasCollectionOldFacturas)) {
                    facturasCollectionOldFacturas.setIdReservacion(null);
                    facturasCollectionOldFacturas = em.merge(facturasCollectionOldFacturas);
                }
            }
            for (Facturas facturasCollectionNewFacturas : facturasCollectionNew) {
                if (!facturasCollectionOld.contains(facturasCollectionNewFacturas)) {
                    Reservaciones oldIdReservacionOfFacturasCollectionNewFacturas = facturasCollectionNewFacturas.getIdReservacion();
                    facturasCollectionNewFacturas.setIdReservacion(reservaciones);
                    facturasCollectionNewFacturas = em.merge(facturasCollectionNewFacturas);
                    if (oldIdReservacionOfFacturasCollectionNewFacturas != null && !oldIdReservacionOfFacturasCollectionNewFacturas.equals(reservaciones)) {
                        oldIdReservacionOfFacturasCollectionNewFacturas.getFacturasCollection().remove(facturasCollectionNewFacturas);
                        oldIdReservacionOfFacturasCollectionNewFacturas = em.merge(oldIdReservacionOfFacturasCollectionNewFacturas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = reservaciones.getIdReservacion();
                if (findReservaciones(id) == null) {
                    throw new NonexistentEntityException("The reservaciones with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Reservaciones reservaciones;
            try {
                reservaciones = em.getReference(Reservaciones.class, id);
                reservaciones.getIdReservacion();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The reservaciones with id " + id + " no longer exists.", enfe);
            }
            Habitaciones idHabitacion = reservaciones.getIdHabitacion();
            if (idHabitacion != null) {
                idHabitacion.getReservacionesCollection().remove(reservaciones);
                idHabitacion = em.merge(idHabitacion);
            }
            Hotel idHotel = reservaciones.getIdHotel();
            if (idHotel != null) {
                idHotel.getReservacionesCollection().remove(reservaciones);
                idHotel = em.merge(idHotel);
            }
            Huespedes identificacion = reservaciones.getIdentificacion();
            if (identificacion != null) {
                identificacion.getReservacionesCollection().remove(reservaciones);
                identificacion = em.merge(identificacion);
            }
            Collection<DetalleFactura> detalleFacturaCollection = reservaciones.getDetalleFacturaCollection();
            for (DetalleFactura detalleFacturaCollectionDetalleFactura : detalleFacturaCollection) {
                detalleFacturaCollectionDetalleFactura.setIdReservacion(null);
                detalleFacturaCollectionDetalleFactura = em.merge(detalleFacturaCollectionDetalleFactura);
            }
            Collection<Checkout> checkoutCollection = reservaciones.getCheckoutCollection();
            for (Checkout checkoutCollectionCheckout : checkoutCollection) {
                checkoutCollectionCheckout.setIdReservacion(null);
                checkoutCollectionCheckout = em.merge(checkoutCollectionCheckout);
            }
            Collection<Facturas> facturasCollection = reservaciones.getFacturasCollection();
            for (Facturas facturasCollectionFacturas : facturasCollection) {
                facturasCollectionFacturas.setIdReservacion(null);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
            }
            em.remove(reservaciones);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Reservaciones> findReservacionesEntities() {
        return findReservacionesEntities(true, -1, -1);
    }

    public List<Reservaciones> findReservacionesEntities(int maxResults, int firstResult) {
        return findReservacionesEntities(false, maxResults, firstResult);
    }

    private List<Reservaciones> findReservacionesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Reservaciones.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Reservaciones findReservaciones(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Reservaciones.class, id);
        } finally {
            em.close();
        }
    }

    public int getReservacionesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Reservaciones> rt = cq.from(Reservaciones.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
