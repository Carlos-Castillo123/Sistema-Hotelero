/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.ServicioExtra;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class ServicioExtraJpaController implements Serializable {

    public ServicioExtraJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ServicioExtra servicioExtra) {
        if (servicioExtra.getDetalleFacturaCollection() == null) {
            servicioExtra.setDetalleFacturaCollection(new ArrayList<DetalleFactura>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<DetalleFactura> attachedDetalleFacturaCollection = new ArrayList<DetalleFactura>();
            for (DetalleFactura detalleFacturaCollectionDetalleFacturaToAttach : servicioExtra.getDetalleFacturaCollection()) {
                detalleFacturaCollectionDetalleFacturaToAttach = em.getReference(detalleFacturaCollectionDetalleFacturaToAttach.getClass(), detalleFacturaCollectionDetalleFacturaToAttach.getIdDetalle());
                attachedDetalleFacturaCollection.add(detalleFacturaCollectionDetalleFacturaToAttach);
            }
            servicioExtra.setDetalleFacturaCollection(attachedDetalleFacturaCollection);
            em.persist(servicioExtra);
            for (DetalleFactura detalleFacturaCollectionDetalleFactura : servicioExtra.getDetalleFacturaCollection()) {
                ServicioExtra oldIdServicioOfDetalleFacturaCollectionDetalleFactura = detalleFacturaCollectionDetalleFactura.getIdServicio();
                detalleFacturaCollectionDetalleFactura.setIdServicio(servicioExtra);
                detalleFacturaCollectionDetalleFactura = em.merge(detalleFacturaCollectionDetalleFactura);
                if (oldIdServicioOfDetalleFacturaCollectionDetalleFactura != null) {
                    oldIdServicioOfDetalleFacturaCollectionDetalleFactura.getDetalleFacturaCollection().remove(detalleFacturaCollectionDetalleFactura);
                    oldIdServicioOfDetalleFacturaCollectionDetalleFactura = em.merge(oldIdServicioOfDetalleFacturaCollectionDetalleFactura);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ServicioExtra servicioExtra) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ServicioExtra persistentServicioExtra = em.find(ServicioExtra.class, servicioExtra.getIdServicio());
            Collection<DetalleFactura> detalleFacturaCollectionOld = persistentServicioExtra.getDetalleFacturaCollection();
            Collection<DetalleFactura> detalleFacturaCollectionNew = servicioExtra.getDetalleFacturaCollection();
            Collection<DetalleFactura> attachedDetalleFacturaCollectionNew = new ArrayList<DetalleFactura>();
            for (DetalleFactura detalleFacturaCollectionNewDetalleFacturaToAttach : detalleFacturaCollectionNew) {
                detalleFacturaCollectionNewDetalleFacturaToAttach = em.getReference(detalleFacturaCollectionNewDetalleFacturaToAttach.getClass(), detalleFacturaCollectionNewDetalleFacturaToAttach.getIdDetalle());
                attachedDetalleFacturaCollectionNew.add(detalleFacturaCollectionNewDetalleFacturaToAttach);
            }
            detalleFacturaCollectionNew = attachedDetalleFacturaCollectionNew;
            servicioExtra.setDetalleFacturaCollection(detalleFacturaCollectionNew);
            servicioExtra = em.merge(servicioExtra);
            for (DetalleFactura detalleFacturaCollectionOldDetalleFactura : detalleFacturaCollectionOld) {
                if (!detalleFacturaCollectionNew.contains(detalleFacturaCollectionOldDetalleFactura)) {
                    detalleFacturaCollectionOldDetalleFactura.setIdServicio(null);
                    detalleFacturaCollectionOldDetalleFactura = em.merge(detalleFacturaCollectionOldDetalleFactura);
                }
            }
            for (DetalleFactura detalleFacturaCollectionNewDetalleFactura : detalleFacturaCollectionNew) {
                if (!detalleFacturaCollectionOld.contains(detalleFacturaCollectionNewDetalleFactura)) {
                    ServicioExtra oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura = detalleFacturaCollectionNewDetalleFactura.getIdServicio();
                    detalleFacturaCollectionNewDetalleFactura.setIdServicio(servicioExtra);
                    detalleFacturaCollectionNewDetalleFactura = em.merge(detalleFacturaCollectionNewDetalleFactura);
                    if (oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura != null && !oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura.equals(servicioExtra)) {
                        oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura.getDetalleFacturaCollection().remove(detalleFacturaCollectionNewDetalleFactura);
                        oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura = em.merge(oldIdServicioOfDetalleFacturaCollectionNewDetalleFactura);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = servicioExtra.getIdServicio();
                if (findServicioExtra(id) == null) {
                    throw new NonexistentEntityException("The servicioExtra with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ServicioExtra servicioExtra;
            try {
                servicioExtra = em.getReference(ServicioExtra.class, id);
                servicioExtra.getIdServicio();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The servicioExtra with id " + id + " no longer exists.", enfe);
            }
            Collection<DetalleFactura> detalleFacturaCollection = servicioExtra.getDetalleFacturaCollection();
            for (DetalleFactura detalleFacturaCollectionDetalleFactura : detalleFacturaCollection) {
                detalleFacturaCollectionDetalleFactura.setIdServicio(null);
                detalleFacturaCollectionDetalleFactura = em.merge(detalleFacturaCollectionDetalleFactura);
            }
            em.remove(servicioExtra);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ServicioExtra> findServicioExtraEntities() {
        return findServicioExtraEntities(true, -1, -1);
    }

    public List<ServicioExtra> findServicioExtraEntities(int maxResults, int firstResult) {
        return findServicioExtraEntities(false, maxResults, firstResult);
    }

    private List<ServicioExtra> findServicioExtraEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ServicioExtra.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ServicioExtra findServicioExtra(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ServicioExtra.class, id);
        } finally {
            em.close();
        }
    }

    public int getServicioExtraCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ServicioExtra> rt = cq.from(ServicioExtra.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
