/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.Reservaciones;
import EntityClases.bd.ServicioExtra;
import EntityClases.bd.Checkout;
import EntityClases.bd.DetalleFactura;
import java.util.ArrayList;
import java.util.Collection;
import EntityClases.bd.Facturas;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class DetalleFacturaJpaController implements Serializable {

    public DetalleFacturaJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(DetalleFactura detalleFactura) {
        if (detalleFactura.getCheckoutCollection() == null) {
            detalleFactura.setCheckoutCollection(new ArrayList<Checkout>());
        }
        if (detalleFactura.getFacturasCollection() == null) {
            detalleFactura.setFacturasCollection(new ArrayList<Facturas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Reservaciones idReservacion = detalleFactura.getIdReservacion();
            if (idReservacion != null) {
                idReservacion = em.getReference(idReservacion.getClass(), idReservacion.getIdReservacion());
                detalleFactura.setIdReservacion(idReservacion);
            }
            ServicioExtra idServicio = detalleFactura.getIdServicio();
            if (idServicio != null) {
                idServicio = em.getReference(idServicio.getClass(), idServicio.getIdServicio());
                detalleFactura.setIdServicio(idServicio);
            }
            Collection<Checkout> attachedCheckoutCollection = new ArrayList<Checkout>();
            for (Checkout checkoutCollectionCheckoutToAttach : detalleFactura.getCheckoutCollection()) {
                checkoutCollectionCheckoutToAttach = em.getReference(checkoutCollectionCheckoutToAttach.getClass(), checkoutCollectionCheckoutToAttach.getIdCheckout());
                attachedCheckoutCollection.add(checkoutCollectionCheckoutToAttach);
            }
            detalleFactura.setCheckoutCollection(attachedCheckoutCollection);
            Collection<Facturas> attachedFacturasCollection = new ArrayList<Facturas>();
            for (Facturas facturasCollectionFacturasToAttach : detalleFactura.getFacturasCollection()) {
                facturasCollectionFacturasToAttach = em.getReference(facturasCollectionFacturasToAttach.getClass(), facturasCollectionFacturasToAttach.getIdFactura());
                attachedFacturasCollection.add(facturasCollectionFacturasToAttach);
            }
            detalleFactura.setFacturasCollection(attachedFacturasCollection);
            em.persist(detalleFactura);
            if (idReservacion != null) {
                idReservacion.getDetalleFacturaCollection().add(detalleFactura);
                idReservacion = em.merge(idReservacion);
            }
            if (idServicio != null) {
                idServicio.getDetalleFacturaCollection().add(detalleFactura);
                idServicio = em.merge(idServicio);
            }
            for (Checkout checkoutCollectionCheckout : detalleFactura.getCheckoutCollection()) {
                DetalleFactura oldIdDetalleOfCheckoutCollectionCheckout = checkoutCollectionCheckout.getIdDetalle();
                checkoutCollectionCheckout.setIdDetalle(detalleFactura);
                checkoutCollectionCheckout = em.merge(checkoutCollectionCheckout);
                if (oldIdDetalleOfCheckoutCollectionCheckout != null) {
                    oldIdDetalleOfCheckoutCollectionCheckout.getCheckoutCollection().remove(checkoutCollectionCheckout);
                    oldIdDetalleOfCheckoutCollectionCheckout = em.merge(oldIdDetalleOfCheckoutCollectionCheckout);
                }
            }
            for (Facturas facturasCollectionFacturas : detalleFactura.getFacturasCollection()) {
                DetalleFactura oldIdDetalleOfFacturasCollectionFacturas = facturasCollectionFacturas.getIdDetalle();
                facturasCollectionFacturas.setIdDetalle(detalleFactura);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
                if (oldIdDetalleOfFacturasCollectionFacturas != null) {
                    oldIdDetalleOfFacturasCollectionFacturas.getFacturasCollection().remove(facturasCollectionFacturas);
                    oldIdDetalleOfFacturasCollectionFacturas = em.merge(oldIdDetalleOfFacturasCollectionFacturas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(DetalleFactura detalleFactura) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            DetalleFactura persistentDetalleFactura = em.find(DetalleFactura.class, detalleFactura.getIdDetalle());
            Reservaciones idReservacionOld = persistentDetalleFactura.getIdReservacion();
            Reservaciones idReservacionNew = detalleFactura.getIdReservacion();
            ServicioExtra idServicioOld = persistentDetalleFactura.getIdServicio();
            ServicioExtra idServicioNew = detalleFactura.getIdServicio();
            Collection<Checkout> checkoutCollectionOld = persistentDetalleFactura.getCheckoutCollection();
            Collection<Checkout> checkoutCollectionNew = detalleFactura.getCheckoutCollection();
            Collection<Facturas> facturasCollectionOld = persistentDetalleFactura.getFacturasCollection();
            Collection<Facturas> facturasCollectionNew = detalleFactura.getFacturasCollection();
            if (idReservacionNew != null) {
                idReservacionNew = em.getReference(idReservacionNew.getClass(), idReservacionNew.getIdReservacion());
                detalleFactura.setIdReservacion(idReservacionNew);
            }
            if (idServicioNew != null) {
                idServicioNew = em.getReference(idServicioNew.getClass(), idServicioNew.getIdServicio());
                detalleFactura.setIdServicio(idServicioNew);
            }
            Collection<Checkout> attachedCheckoutCollectionNew = new ArrayList<Checkout>();
            for (Checkout checkoutCollectionNewCheckoutToAttach : checkoutCollectionNew) {
                checkoutCollectionNewCheckoutToAttach = em.getReference(checkoutCollectionNewCheckoutToAttach.getClass(), checkoutCollectionNewCheckoutToAttach.getIdCheckout());
                attachedCheckoutCollectionNew.add(checkoutCollectionNewCheckoutToAttach);
            }
            checkoutCollectionNew = attachedCheckoutCollectionNew;
            detalleFactura.setCheckoutCollection(checkoutCollectionNew);
            Collection<Facturas> attachedFacturasCollectionNew = new ArrayList<Facturas>();
            for (Facturas facturasCollectionNewFacturasToAttach : facturasCollectionNew) {
                facturasCollectionNewFacturasToAttach = em.getReference(facturasCollectionNewFacturasToAttach.getClass(), facturasCollectionNewFacturasToAttach.getIdFactura());
                attachedFacturasCollectionNew.add(facturasCollectionNewFacturasToAttach);
            }
            facturasCollectionNew = attachedFacturasCollectionNew;
            detalleFactura.setFacturasCollection(facturasCollectionNew);
            detalleFactura = em.merge(detalleFactura);
            if (idReservacionOld != null && !idReservacionOld.equals(idReservacionNew)) {
                idReservacionOld.getDetalleFacturaCollection().remove(detalleFactura);
                idReservacionOld = em.merge(idReservacionOld);
            }
            if (idReservacionNew != null && !idReservacionNew.equals(idReservacionOld)) {
                idReservacionNew.getDetalleFacturaCollection().add(detalleFactura);
                idReservacionNew = em.merge(idReservacionNew);
            }
            if (idServicioOld != null && !idServicioOld.equals(idServicioNew)) {
                idServicioOld.getDetalleFacturaCollection().remove(detalleFactura);
                idServicioOld = em.merge(idServicioOld);
            }
            if (idServicioNew != null && !idServicioNew.equals(idServicioOld)) {
                idServicioNew.getDetalleFacturaCollection().add(detalleFactura);
                idServicioNew = em.merge(idServicioNew);
            }
            for (Checkout checkoutCollectionOldCheckout : checkoutCollectionOld) {
                if (!checkoutCollectionNew.contains(checkoutCollectionOldCheckout)) {
                    checkoutCollectionOldCheckout.setIdDetalle(null);
                    checkoutCollectionOldCheckout = em.merge(checkoutCollectionOldCheckout);
                }
            }
            for (Checkout checkoutCollectionNewCheckout : checkoutCollectionNew) {
                if (!checkoutCollectionOld.contains(checkoutCollectionNewCheckout)) {
                    DetalleFactura oldIdDetalleOfCheckoutCollectionNewCheckout = checkoutCollectionNewCheckout.getIdDetalle();
                    checkoutCollectionNewCheckout.setIdDetalle(detalleFactura);
                    checkoutCollectionNewCheckout = em.merge(checkoutCollectionNewCheckout);
                    if (oldIdDetalleOfCheckoutCollectionNewCheckout != null && !oldIdDetalleOfCheckoutCollectionNewCheckout.equals(detalleFactura)) {
                        oldIdDetalleOfCheckoutCollectionNewCheckout.getCheckoutCollection().remove(checkoutCollectionNewCheckout);
                        oldIdDetalleOfCheckoutCollectionNewCheckout = em.merge(oldIdDetalleOfCheckoutCollectionNewCheckout);
                    }
                }
            }
            for (Facturas facturasCollectionOldFacturas : facturasCollectionOld) {
                if (!facturasCollectionNew.contains(facturasCollectionOldFacturas)) {
                    facturasCollectionOldFacturas.setIdDetalle(null);
                    facturasCollectionOldFacturas = em.merge(facturasCollectionOldFacturas);
                }
            }
            for (Facturas facturasCollectionNewFacturas : facturasCollectionNew) {
                if (!facturasCollectionOld.contains(facturasCollectionNewFacturas)) {
                    DetalleFactura oldIdDetalleOfFacturasCollectionNewFacturas = facturasCollectionNewFacturas.getIdDetalle();
                    facturasCollectionNewFacturas.setIdDetalle(detalleFactura);
                    facturasCollectionNewFacturas = em.merge(facturasCollectionNewFacturas);
                    if (oldIdDetalleOfFacturasCollectionNewFacturas != null && !oldIdDetalleOfFacturasCollectionNewFacturas.equals(detalleFactura)) {
                        oldIdDetalleOfFacturasCollectionNewFacturas.getFacturasCollection().remove(facturasCollectionNewFacturas);
                        oldIdDetalleOfFacturasCollectionNewFacturas = em.merge(oldIdDetalleOfFacturasCollectionNewFacturas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = detalleFactura.getIdDetalle();
                if (findDetalleFactura(id) == null) {
                    throw new NonexistentEntityException("The detalleFactura with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            DetalleFactura detalleFactura;
            try {
                detalleFactura = em.getReference(DetalleFactura.class, id);
                detalleFactura.getIdDetalle();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The detalleFactura with id " + id + " no longer exists.", enfe);
            }
            Reservaciones idReservacion = detalleFactura.getIdReservacion();
            if (idReservacion != null) {
                idReservacion.getDetalleFacturaCollection().remove(detalleFactura);
                idReservacion = em.merge(idReservacion);
            }
            ServicioExtra idServicio = detalleFactura.getIdServicio();
            if (idServicio != null) {
                idServicio.getDetalleFacturaCollection().remove(detalleFactura);
                idServicio = em.merge(idServicio);
            }
            Collection<Checkout> checkoutCollection = detalleFactura.getCheckoutCollection();
            for (Checkout checkoutCollectionCheckout : checkoutCollection) {
                checkoutCollectionCheckout.setIdDetalle(null);
                checkoutCollectionCheckout = em.merge(checkoutCollectionCheckout);
            }
            Collection<Facturas> facturasCollection = detalleFactura.getFacturasCollection();
            for (Facturas facturasCollectionFacturas : facturasCollection) {
                facturasCollectionFacturas.setIdDetalle(null);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
            }
            em.remove(detalleFactura);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<DetalleFactura> findDetalleFacturaEntities() {
        return findDetalleFacturaEntities(true, -1, -1);
    }

    public List<DetalleFactura> findDetalleFacturaEntities(int maxResults, int firstResult) {
        return findDetalleFacturaEntities(false, maxResults, firstResult);
    }

    private List<DetalleFactura> findDetalleFacturaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(DetalleFactura.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public DetalleFactura findDetalleFactura(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(DetalleFactura.class, id);
        } finally {
            em.close();
        }
    }

    public int getDetalleFacturaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<DetalleFactura> rt = cq.from(DetalleFactura.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
