/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import EntityClases.bd.Checkout;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.Reservaciones;
import EntityClases.bd.Facturas;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class CheckoutJpaController implements Serializable {

    public CheckoutJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Checkout checkout) {
        if (checkout.getFacturasCollection() == null) {
            checkout.setFacturasCollection(new ArrayList<Facturas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            DetalleFactura idDetalle = checkout.getIdDetalle();
            if (idDetalle != null) {
                idDetalle = em.getReference(idDetalle.getClass(), idDetalle.getIdDetalle());
                checkout.setIdDetalle(idDetalle);
            }
            Reservaciones idReservacion = checkout.getIdReservacion();
            if (idReservacion != null) {
                idReservacion = em.getReference(idReservacion.getClass(), idReservacion.getIdReservacion());
                checkout.setIdReservacion(idReservacion);
            }
            Collection<Facturas> attachedFacturasCollection = new ArrayList<Facturas>();
            for (Facturas facturasCollectionFacturasToAttach : checkout.getFacturasCollection()) {
                facturasCollectionFacturasToAttach = em.getReference(facturasCollectionFacturasToAttach.getClass(), facturasCollectionFacturasToAttach.getIdFactura());
                attachedFacturasCollection.add(facturasCollectionFacturasToAttach);
            }
            checkout.setFacturasCollection(attachedFacturasCollection);
            em.persist(checkout);
            if (idDetalle != null) {
                idDetalle.getCheckoutCollection().add(checkout);
                idDetalle = em.merge(idDetalle);
            }
            if (idReservacion != null) {
                idReservacion.getCheckoutCollection().add(checkout);
                idReservacion = em.merge(idReservacion);
            }
            for (Facturas facturasCollectionFacturas : checkout.getFacturasCollection()) {
                Checkout oldIdCheckoutOfFacturasCollectionFacturas = facturasCollectionFacturas.getIdCheckout();
                facturasCollectionFacturas.setIdCheckout(checkout);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
                if (oldIdCheckoutOfFacturasCollectionFacturas != null) {
                    oldIdCheckoutOfFacturasCollectionFacturas.getFacturasCollection().remove(facturasCollectionFacturas);
                    oldIdCheckoutOfFacturasCollectionFacturas = em.merge(oldIdCheckoutOfFacturasCollectionFacturas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Checkout checkout) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Checkout persistentCheckout = em.find(Checkout.class, checkout.getIdCheckout());
            DetalleFactura idDetalleOld = persistentCheckout.getIdDetalle();
            DetalleFactura idDetalleNew = checkout.getIdDetalle();
            Reservaciones idReservacionOld = persistentCheckout.getIdReservacion();
            Reservaciones idReservacionNew = checkout.getIdReservacion();
            Collection<Facturas> facturasCollectionOld = persistentCheckout.getFacturasCollection();
            Collection<Facturas> facturasCollectionNew = checkout.getFacturasCollection();
            if (idDetalleNew != null) {
                idDetalleNew = em.getReference(idDetalleNew.getClass(), idDetalleNew.getIdDetalle());
                checkout.setIdDetalle(idDetalleNew);
            }
            if (idReservacionNew != null) {
                idReservacionNew = em.getReference(idReservacionNew.getClass(), idReservacionNew.getIdReservacion());
                checkout.setIdReservacion(idReservacionNew);
            }
            Collection<Facturas> attachedFacturasCollectionNew = new ArrayList<Facturas>();
            for (Facturas facturasCollectionNewFacturasToAttach : facturasCollectionNew) {
                facturasCollectionNewFacturasToAttach = em.getReference(facturasCollectionNewFacturasToAttach.getClass(), facturasCollectionNewFacturasToAttach.getIdFactura());
                attachedFacturasCollectionNew.add(facturasCollectionNewFacturasToAttach);
            }
            facturasCollectionNew = attachedFacturasCollectionNew;
            checkout.setFacturasCollection(facturasCollectionNew);
            checkout = em.merge(checkout);
            if (idDetalleOld != null && !idDetalleOld.equals(idDetalleNew)) {
                idDetalleOld.getCheckoutCollection().remove(checkout);
                idDetalleOld = em.merge(idDetalleOld);
            }
            if (idDetalleNew != null && !idDetalleNew.equals(idDetalleOld)) {
                idDetalleNew.getCheckoutCollection().add(checkout);
                idDetalleNew = em.merge(idDetalleNew);
            }
            if (idReservacionOld != null && !idReservacionOld.equals(idReservacionNew)) {
                idReservacionOld.getCheckoutCollection().remove(checkout);
                idReservacionOld = em.merge(idReservacionOld);
            }
            if (idReservacionNew != null && !idReservacionNew.equals(idReservacionOld)) {
                idReservacionNew.getCheckoutCollection().add(checkout);
                idReservacionNew = em.merge(idReservacionNew);
            }
            for (Facturas facturasCollectionOldFacturas : facturasCollectionOld) {
                if (!facturasCollectionNew.contains(facturasCollectionOldFacturas)) {
                    facturasCollectionOldFacturas.setIdCheckout(null);
                    facturasCollectionOldFacturas = em.merge(facturasCollectionOldFacturas);
                }
            }
            for (Facturas facturasCollectionNewFacturas : facturasCollectionNew) {
                if (!facturasCollectionOld.contains(facturasCollectionNewFacturas)) {
                    Checkout oldIdCheckoutOfFacturasCollectionNewFacturas = facturasCollectionNewFacturas.getIdCheckout();
                    facturasCollectionNewFacturas.setIdCheckout(checkout);
                    facturasCollectionNewFacturas = em.merge(facturasCollectionNewFacturas);
                    if (oldIdCheckoutOfFacturasCollectionNewFacturas != null && !oldIdCheckoutOfFacturasCollectionNewFacturas.equals(checkout)) {
                        oldIdCheckoutOfFacturasCollectionNewFacturas.getFacturasCollection().remove(facturasCollectionNewFacturas);
                        oldIdCheckoutOfFacturasCollectionNewFacturas = em.merge(oldIdCheckoutOfFacturasCollectionNewFacturas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = checkout.getIdCheckout();
                if (findCheckout(id) == null) {
                    throw new NonexistentEntityException("The checkout with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Checkout checkout;
            try {
                checkout = em.getReference(Checkout.class, id);
                checkout.getIdCheckout();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The checkout with id " + id + " no longer exists.", enfe);
            }
            DetalleFactura idDetalle = checkout.getIdDetalle();
            if (idDetalle != null) {
                idDetalle.getCheckoutCollection().remove(checkout);
                idDetalle = em.merge(idDetalle);
            }
            Reservaciones idReservacion = checkout.getIdReservacion();
            if (idReservacion != null) {
                idReservacion.getCheckoutCollection().remove(checkout);
                idReservacion = em.merge(idReservacion);
            }
            Collection<Facturas> facturasCollection = checkout.getFacturasCollection();
            for (Facturas facturasCollectionFacturas : facturasCollection) {
                facturasCollectionFacturas.setIdCheckout(null);
                facturasCollectionFacturas = em.merge(facturasCollectionFacturas);
            }
            em.remove(checkout);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Checkout> findCheckoutEntities() {
        return findCheckoutEntities(true, -1, -1);
    }

    public List<Checkout> findCheckoutEntities(int maxResults, int firstResult) {
        return findCheckoutEntities(false, maxResults, firstResult);
    }

    private List<Checkout> findCheckoutEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Checkout.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Checkout findCheckout(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Checkout.class, id);
        } finally {
            em.close();
        }
    }

    public int getCheckoutCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Checkout> rt = cq.from(Checkout.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
