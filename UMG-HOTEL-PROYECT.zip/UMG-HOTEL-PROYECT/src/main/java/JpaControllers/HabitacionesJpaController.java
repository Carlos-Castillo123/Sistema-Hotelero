/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import EntityClases.bd.CategoriaHabitacion;
import EntityClases.bd.Habitaciones;
import EntityClases.bd.Hotel;
import EntityClases.bd.Reservaciones;
import JpaControllers.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author Elacr
 */
public class HabitacionesJpaController implements Serializable {

    public HabitacionesJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Habitaciones habitaciones) {
        if (habitaciones.getReservacionesCollection() == null) {
            habitaciones.setReservacionesCollection(new ArrayList<Reservaciones>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            CategoriaHabitacion idCategoria = habitaciones.getIdCategoria();
            if (idCategoria != null) {
                idCategoria = em.getReference(idCategoria.getClass(), idCategoria.getIdCategoria());
                habitaciones.setIdCategoria(idCategoria);
            }
            Hotel idHotel = habitaciones.getIdHotel();
            if (idHotel != null) {
                idHotel = em.getReference(idHotel.getClass(), idHotel.getIdHotel());
                habitaciones.setIdHotel(idHotel);
            }
            Collection<Reservaciones> attachedReservacionesCollection = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionReservacionesToAttach : habitaciones.getReservacionesCollection()) {
                reservacionesCollectionReservacionesToAttach = em.getReference(reservacionesCollectionReservacionesToAttach.getClass(), reservacionesCollectionReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollection.add(reservacionesCollectionReservacionesToAttach);
            }
            habitaciones.setReservacionesCollection(attachedReservacionesCollection);
            em.persist(habitaciones);
            if (idCategoria != null) {
                idCategoria.getHabitacionesCollection().add(habitaciones);
                idCategoria = em.merge(idCategoria);
            }
            if (idHotel != null) {
                idHotel.getHabitacionesCollection().add(habitaciones);
                idHotel = em.merge(idHotel);
            }
            for (Reservaciones reservacionesCollectionReservaciones : habitaciones.getReservacionesCollection()) {
                Habitaciones oldIdHabitacionOfReservacionesCollectionReservaciones = reservacionesCollectionReservaciones.getIdHabitacion();
                reservacionesCollectionReservaciones.setIdHabitacion(habitaciones);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
                if (oldIdHabitacionOfReservacionesCollectionReservaciones != null) {
                    oldIdHabitacionOfReservacionesCollectionReservaciones.getReservacionesCollection().remove(reservacionesCollectionReservaciones);
                    oldIdHabitacionOfReservacionesCollectionReservaciones = em.merge(oldIdHabitacionOfReservacionesCollectionReservaciones);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Habitaciones habitaciones) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Habitaciones persistentHabitaciones = em.find(Habitaciones.class, habitaciones.getIdHabitacion());
            CategoriaHabitacion idCategoriaOld = persistentHabitaciones.getIdCategoria();
            CategoriaHabitacion idCategoriaNew = habitaciones.getIdCategoria();
            Hotel idHotelOld = persistentHabitaciones.getIdHotel();
            Hotel idHotelNew = habitaciones.getIdHotel();
            Collection<Reservaciones> reservacionesCollectionOld = persistentHabitaciones.getReservacionesCollection();
            Collection<Reservaciones> reservacionesCollectionNew = habitaciones.getReservacionesCollection();
            if (idCategoriaNew != null) {
                idCategoriaNew = em.getReference(idCategoriaNew.getClass(), idCategoriaNew.getIdCategoria());
                habitaciones.setIdCategoria(idCategoriaNew);
            }
            if (idHotelNew != null) {
                idHotelNew = em.getReference(idHotelNew.getClass(), idHotelNew.getIdHotel());
                habitaciones.setIdHotel(idHotelNew);
            }
            Collection<Reservaciones> attachedReservacionesCollectionNew = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionNewReservacionesToAttach : reservacionesCollectionNew) {
                reservacionesCollectionNewReservacionesToAttach = em.getReference(reservacionesCollectionNewReservacionesToAttach.getClass(), reservacionesCollectionNewReservacionesToAttach.getIdReservacion());
                attachedReservacionesCollectionNew.add(reservacionesCollectionNewReservacionesToAttach);
            }
            reservacionesCollectionNew = attachedReservacionesCollectionNew;
            habitaciones.setReservacionesCollection(reservacionesCollectionNew);
            habitaciones = em.merge(habitaciones);
            if (idCategoriaOld != null && !idCategoriaOld.equals(idCategoriaNew)) {
                idCategoriaOld.getHabitacionesCollection().remove(habitaciones);
                idCategoriaOld = em.merge(idCategoriaOld);
            }
            if (idCategoriaNew != null && !idCategoriaNew.equals(idCategoriaOld)) {
                idCategoriaNew.getHabitacionesCollection().add(habitaciones);
                idCategoriaNew = em.merge(idCategoriaNew);
            }
            if (idHotelOld != null && !idHotelOld.equals(idHotelNew)) {
                idHotelOld.getHabitacionesCollection().remove(habitaciones);
                idHotelOld = em.merge(idHotelOld);
            }
            if (idHotelNew != null && !idHotelNew.equals(idHotelOld)) {
                idHotelNew.getHabitacionesCollection().add(habitaciones);
                idHotelNew = em.merge(idHotelNew);
            }
            for (Reservaciones reservacionesCollectionOldReservaciones : reservacionesCollectionOld) {
                if (!reservacionesCollectionNew.contains(reservacionesCollectionOldReservaciones)) {
                    reservacionesCollectionOldReservaciones.setIdHabitacion(null);
                    reservacionesCollectionOldReservaciones = em.merge(reservacionesCollectionOldReservaciones);
                }
            }
            for (Reservaciones reservacionesCollectionNewReservaciones : reservacionesCollectionNew) {
                if (!reservacionesCollectionOld.contains(reservacionesCollectionNewReservaciones)) {
                    Habitaciones oldIdHabitacionOfReservacionesCollectionNewReservaciones = reservacionesCollectionNewReservaciones.getIdHabitacion();
                    reservacionesCollectionNewReservaciones.setIdHabitacion(habitaciones);
                    reservacionesCollectionNewReservaciones = em.merge(reservacionesCollectionNewReservaciones);
                    if (oldIdHabitacionOfReservacionesCollectionNewReservaciones != null && !oldIdHabitacionOfReservacionesCollectionNewReservaciones.equals(habitaciones)) {
                        oldIdHabitacionOfReservacionesCollectionNewReservaciones.getReservacionesCollection().remove(reservacionesCollectionNewReservaciones);
                        oldIdHabitacionOfReservacionesCollectionNewReservaciones = em.merge(oldIdHabitacionOfReservacionesCollectionNewReservaciones);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = habitaciones.getIdHabitacion();
                if (findHabitaciones(id) == null) {
                    throw new NonexistentEntityException("The habitaciones with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Habitaciones habitaciones;
            try {
                habitaciones = em.getReference(Habitaciones.class, id);
                habitaciones.getIdHabitacion();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The habitaciones with id " + id + " no longer exists.", enfe);
            }
            CategoriaHabitacion idCategoria = habitaciones.getIdCategoria();
            if (idCategoria != null) {
                idCategoria.getHabitacionesCollection().remove(habitaciones);
                idCategoria = em.merge(idCategoria);
            }
            Hotel idHotel = habitaciones.getIdHotel();
            if (idHotel != null) {
                idHotel.getHabitacionesCollection().remove(habitaciones);
                idHotel = em.merge(idHotel);
            }
            Collection<Reservaciones> reservacionesCollection = habitaciones.getReservacionesCollection();
            for (Reservaciones reservacionesCollectionReservaciones : reservacionesCollection) {
                reservacionesCollectionReservaciones.setIdHabitacion(null);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
            }
            em.remove(habitaciones);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Habitaciones> findHabitacionesEntities() {
        return findHabitacionesEntities(true, -1, -1);
    }

    public List<Habitaciones> findHabitacionesEntities(int maxResults, int firstResult) {
        return findHabitacionesEntities(false, maxResults, firstResult);
    }

    private List<Habitaciones> findHabitacionesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Habitaciones.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Habitaciones findHabitaciones(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Habitaciones.class, id);
        } finally {
            em.close();
        }
    }

    public int getHabitacionesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Habitaciones> rt = cq.from(Habitaciones.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
