/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Hotel;
import JpaControllers.HotelJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PHotel {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Hotel CH = new Hotel();
            System.out.println("Ingresando nuevo Hotel:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Nombre:");
            String nombre = esc.nextLine();
            CH.setNombre(nombre);
            
            System.out.println("Ingresa Direccion:");
            String direccion = esc.nextLine();
            CH.setDireccion(direccion);
            
            System.out.println("Ingresa Telefono:");
            int telefono = esc.nextInt();
            CH.setTelefono(telefono);

            // Iniciar la transacción
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
        System.out.println("-----------------------");
        // Crear lista pa   ra almacenar los datos de la base de datos
        List<Hotel> CHarray = new ArrayList<>();
        HotelJpaController ac = new HotelJpaController(emf); // Usar el JpaController

        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findHotelEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Hotel al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Id_Hotel: " + al.getIdHotel());
            System.out.println("Nombre: " + al.getNombre());
            System.out.println("Direccion: " + al.getDireccion());
            System.out.println("Telefono: " + al.getTelefono());
        }
        System.out.println("-------------------");
    }
}
