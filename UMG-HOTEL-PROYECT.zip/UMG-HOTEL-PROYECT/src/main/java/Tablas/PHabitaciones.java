/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.CategoriaHabitacion;
import EntityClases.bd.Habitaciones;
import EntityClases.bd.Hotel;
import JpaControllers.HabitacionesJpaController;
import JpaControllers.HotelJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PHabitaciones {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Habitaciones CH = new Habitaciones();
            System.out.println("Ingresando nueva Habitacion:");
            System.out.println("-----------------------");
            System.out.println("Ingresa ID Hotel:");
            int idhotel = esc.nextInt();
            Hotel hotelid = em.find(Hotel.class, idhotel);
            CH.setIdHotel(hotelid);

            
            System.out.println("Ingresa ID Categoria:");
            int idcat = esc.nextInt();
            CategoriaHabitacion catid = em.find(CategoriaHabitacion.class, idcat);
            CH.setIdCategoria(catid);

            esc.nextLine(); // Capturar el salto de línea
            System.out.println("Ingresa No. Habitacion:");
            String NHabi = esc.nextLine();
            CH.setNoHabitacion(NHabi);
            
            System.out.println("Ingresa Precio Por Noche:");
            Double Precio = esc.nextDouble();
            CH.setPrecioNoche(Precio);
            
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Habitaciones> CHarray = new ArrayList<>();
        HabitacionesJpaController ac = new HabitacionesJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findHabitacionesEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Habitaciones al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Id_Habitacion: " + al.getIdHabitacion());
            int a = al.getIdHotel().getIdHotel(); int b = al.getIdCategoria().getIdCategoria();
            System.out.println("Id_Hotel: " + a);
            System.out.println("Id_Categoria: " + b);
            System.out.println("No. de Habitacion: " + al.getNoHabitacion());
            System.out.println("Precio por noche:"  + al.getPrecioNoche());
        }
        System.out.println("-------------------");
    }
}