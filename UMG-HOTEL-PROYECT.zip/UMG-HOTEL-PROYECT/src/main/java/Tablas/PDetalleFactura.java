/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.CategoriaHabitacion;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.Habitaciones;
import EntityClases.bd.Reservaciones;
import EntityClases.bd.ServicioExtra;
import EntityClases.bd.Usuarios;
import JpaControllers.DetalleFacturaJpaController;
import JpaControllers.ServicioExtraJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */


public class PDetalleFactura {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            DetalleFactura CH = new DetalleFactura();
            System.out.println("Ingresando nuevo Detalle-Factura:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Id reservacion:");
            int ires = esc.nextInt();
            
            Reservaciones irs = em.find(Reservaciones.class, ires);
            CH.setIdReservacion(irs);
            System.out.println("Descripcion: " + irs.getIdHabitacion().getIdCategoria().getDescripcion());
            System.out.println("Precio: " + irs.getIdHabitacion().getPrecioNoche());
            System.out.println("Cantidad de Noches: " + irs.getCantidadNoches());
            System.out.println("Total Reservacion: " + irs.getCantidadNoches()*irs.getIdHabitacion().getPrecioNoche());
            System.out.println("-------------------------------------------");
            CH.setDescripcion(irs.getIdHabitacion().getIdCategoria().getDescripcion());
            CH.setPrecioUnitario(irs.getIdHabitacion().getPrecioNoche());
            CH.setCantidad(irs.getCantidadNoches());
            CH.setPrecioTotal(irs.getCantidadNoches()*irs.getIdHabitacion().getPrecioNoche());
            
            
            System.out.println("Ingresa Id Servicio:");
            int iser = esc.nextInt();
            ServicioExtra ids = em.find(ServicioExtra.class, iser);
            CH.setIdServicio(ids);
            esc.nextLine();
            System.out.println("Nombre:" + ids.getDescripcion());
            CH.setNombre(ids.getDescripcion());
            

            
            System.out.println("Ingresa Cantidad:");
            int cant = esc.nextInt();
            CH.setCantidad(cant);
            
            System.out.println("Precio Unitario: " + ids.getPrecio());
           // CH.setPrecioUnitario(ids.getPrecio());
            
            System.out.println("Precio Total: " + ids.getTotalServicio());
           // CH.setPrecioTotal(ids.getTotalServicio());
            
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<DetalleFactura> CHarray = new ArrayList<>();
        DetalleFacturaJpaController ac = new DetalleFacturaJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findDetalleFacturaEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (DetalleFactura al : CHarray) {
            System.out.println("-------------------");
            System.out.println("ID Detalle: " + al.getIdDetalle());
            System.out.println("ID Reservacion: " + al.getIdReservacion());
            System.out.println("ID Servicio: " + al.getIdServicio());
            System.out.println("Nombre: " + al.getNombre());
            System.out.println("Descripcion: " + al.getDescripcion());
            System.out.println("Cantidad: " + al.getCantidad());
            System.out.println("Precio Unitario: " + al.getPrecioUnitario());
            System.out.println("Precio Total: " + al.getPrecioTotal());
        }   
        System.out.println("-------------------");
    }
}
