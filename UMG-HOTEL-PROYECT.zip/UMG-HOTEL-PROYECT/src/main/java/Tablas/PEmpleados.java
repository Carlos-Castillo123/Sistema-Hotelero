/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Empleados;
import EntityClases.bd.Hotel;
import JpaControllers.EmpleadosJpaController;
import JpaControllers.HotelJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PEmpleados {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Empleados CH = new Empleados();
            System.out.println("Ingresando nuevo Empleado:");
            System.out.println("-----------------------");
            System.out.println("Ingresa ID Hotel:");
            int idhotel = esc.nextInt();
            Hotel hotelid = em.find(Hotel.class, idhotel);
            CH.setIdHotel(hotelid);
            esc.nextLine();
            System.out.println("Ingresa Nombres:");
            String names = esc.nextLine();
            CH.setNombres(names);
            
            System.out.println("Ingresa Apellidos:");
            String apellidos = esc.nextLine();
            CH.setApellidos(apellidos);
            
            System.out.println("Ingresa Email:");
            String email = esc.nextLine();
            CH.setEmail(email);
            
            System.out.println("Ingresa Telefono:");
            String tel = esc.nextLine();
            CH.setTelefono(tel);
            
            System.out.println("Ingresa Area:");
            String area = esc.nextLine();
            CH.setArea(area);
            
            // Iniciar la transacción
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
        System.out.println("-----------------------");
        // Crear lista para almacenar los datos de la base de datos
        List<Empleados> CHarray = new ArrayList<>();
        EmpleadosJpaController ac = new EmpleadosJpaController(emf); // Usar el JpaController

        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findEmpleadosEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Empleados al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Id_Empleado: " + al.getIdEmpleado());
            System.out.println("Id_Hotel: " + al.getIdHotel().getIdHotel());
            System.out.println("Nombre: " + al.getIdHotel().getIdHotel());
            System.out.println("Direccion: " + al.getNombres());
            System.out.println("Telefono: " + al.getTelefono());
            System.out.println("Area: " + al.getArea());
        }
        System.out.println("-------------------");
    }
}
