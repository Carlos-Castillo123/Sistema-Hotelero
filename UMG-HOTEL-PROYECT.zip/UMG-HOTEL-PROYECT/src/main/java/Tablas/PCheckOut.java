/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Checkout;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.Reservaciones;
import EntityClases.bd.ServicioExtra;
import JpaControllers.CheckoutJpaController;
import JpaControllers.DetalleFacturaJpaController;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PCheckOut {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Checkout CH = new Checkout();
            System.out.println("Ingresando nuevo CheckOut:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Id reservacion:");
            int ires = esc.nextInt();
            Reservaciones irs = em.find(Reservaciones.class, ires);
            CH.setIdReservacion(irs);
            
            System.out.println("Ingresa Id Detalles:");
            int iser = esc.nextInt();
            DetalleFactura ids = em.find(DetalleFactura.class, iser);
            CH.setIdDetalle(ids);
            esc.nextLine();
            
            System.out.println("Ingresa Fecha Checkout:");
            String fechaCheckout = esc.nextLine();
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = formato.parse(fechaCheckout);
            CH.setFechaCheckout(fecha);
            
            System.out.println("Ingresa Hora Checkout:");
            String HoraIn = esc.nextLine();
            SimpleDateFormat formatoo = new SimpleDateFormat("HH:mm:ss");
            Date HorasIn = formatoo.parse(HoraIn);
            CH.setHoraCheckout(HorasIn);
            
            System.out.println("Ingresa Metodo de Pago:");
            String cant = esc.nextLine();
            CH.setMetodoPago(cant);
            
            System.out.println("Total a Pagar: " + ids.getPrecioTotal());
            CH.setTotalPagar(ids.getPrecioTotal());
            
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Checkout> CHarray = new ArrayList<>();
        CheckoutJpaController ac = new CheckoutJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findCheckoutEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        
        for (Checkout al : CHarray) {
            System.out.println("-------------------");
            System.out.println("ID Checkout: " + al.getIdCheckout());
            System.out.println("ID Reservacion: " + al.getIdReservacion().getIdReservacion());
            System.out.println("ID Detalle: " + al.getIdDetalle().getIdDetalle());
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Fecha Checkout: " + formato.format(al.getFechaCheckout()));
            SimpleDateFormat formatoo = new SimpleDateFormat("HH:mm:ss");
            System.out.println("Hora Checkout: " + formatoo.format(al.getHoraCheckout()));
            System.out.println("Metodo de Pago: " + al.getMetodoPago());
            System.out.println("Total a Pagar: " + al.getTotalPagar());
        }   
        System.out.println("-------------------");
    }
}