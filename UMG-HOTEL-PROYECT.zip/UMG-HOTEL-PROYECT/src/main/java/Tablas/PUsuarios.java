/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Usuarios;
import JpaControllers.UsuariosJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PUsuarios {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Usuarios CH = new Usuarios();
            System.out.println("Ingresando nuevo Usuario:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Contrasena:");
            String idcat = esc.nextLine();
            CH.setContasena(idcat);

            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Usuarios> CHarray = new ArrayList<>();
        UsuariosJpaController ac = new UsuariosJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findUsuariosEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Usuarios al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Usuario: " + al.getUsuario());
            System.out.println("Contrasena: " + al.getContasena());
        }   
        System.out.println("-------------------");
    }
}
