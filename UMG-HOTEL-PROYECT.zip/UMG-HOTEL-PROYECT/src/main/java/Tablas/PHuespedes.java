/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Huespedes;
import EntityClases.bd.Usuarios;
import JpaControllers.HuespedesJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PHuespedes {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Huespedes CH = new Huespedes();
            System.out.println("Ingresando nuevo Huesped:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Identificacion:");
            String idp = esc.nextLine();
            CH.setIdentificacion(idp);
            
            System.out.println("Ingresa Usuario:");
            int usser = esc.nextInt();
            Usuarios Usu = em.find(Usuarios.class, usser);
            CH.setUsuario(Usu);
            esc.nextLine();
            System.out.println("Ingresa Nombres:");
            String names = esc.nextLine();
            CH.setNombres(names);
            
            System.out.println("Ingresa Apellidos:");
            String apell = esc.nextLine();
            CH.setApellidos(apell);
            
            System.out.println("Ingresa Email:");
            String email = esc.nextLine();
            CH.setEmail(email);
            
            System.out.println("Ingresa Telefono:");
            String num = esc.nextLine();
            CH.setTelefono(num);
            
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Huespedes> CHarray = new ArrayList<>();
        HuespedesJpaController ac = new HuespedesJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findHuespedesEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Huespedes al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Identificacion: " + al.getIdentificacion());
            System.out.println("Usuario: " + al.getUsuario().getUsuario());
            System.out.println("Nombres: " + al.getNombres());
            System.out.println("Apellidos: " + al.getApellidos());
            System.out.println("Email: " + al.getEmail());
            System.out.println("Telefono: " + al.getTelefono());
        }   
        System.out.println("-------------------");
    }
}
