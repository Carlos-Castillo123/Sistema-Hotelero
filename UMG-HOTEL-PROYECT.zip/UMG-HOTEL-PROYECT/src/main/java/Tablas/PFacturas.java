/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.Checkout;
import EntityClases.bd.DetalleFactura;
import EntityClases.bd.Facturas;
import EntityClases.bd.Hotel;
import EntityClases.bd.Reservaciones;
import JpaControllers.CheckoutJpaController;
import JpaControllers.FacturasJpaController;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PFacturas {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Facturas CH = new Facturas();
            System.out.println("Ingresando nueva Factura:");
            System.out.println("-----------------------");
            System.out.println("Ingresa Id Hotel:");
            int ires = esc.nextInt();
            Hotel irs = em.find(Hotel.class, ires);
            CH.setIdHotel(irs);
            
            System.out.println("Ingresa Id reservacion:");
            int reserva = esc.nextInt();
            Reservaciones idreserva = em.find(Reservaciones.class, reserva);
            CH.setIdReservacion(idreserva);
            
            System.out.println("Ingresa Id Detalles:");
            int iser = esc.nextInt();
            DetalleFactura ids = em.find(DetalleFactura.class, iser);
            CH.setIdDetalle(ids);
            
            System.out.println("Ingresa Id Checkout:");
            int check = esc.nextInt();
            Checkout out = em.find(Checkout.class, check);
            CH.setIdCheckout(out);
            esc.nextLine();
            
            System.out.println("Metodo de Pago: " + out.getMetodoPago());
            CH.setMetodoPago(out.getMetodoPago());
            
            System.out.println("Ingresa NIT:");
            String nit = esc.nextLine();
            CH.setNit(nit);
            
            System.out.println("Ingresa Fecha Emision(yyyy-MM-dd):");
            String fechaemision = esc.nextLine();
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = formato.parse(fechaemision);
            CH.setFechaEmision(fecha);
            
            System.out.println("Total a Pagar: " + out.getTotalPagar());
            BigDecimal Total = BigDecimal.valueOf(out.getTotalPagar());
            CH.setTotalPagar(Total);
            
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Facturas> CHarray = new ArrayList<>();
        FacturasJpaController ac = new FacturasJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findFacturasEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        
        for (Facturas al : CHarray) {
            System.out.println("-------------------");
            System.out.println("ID Factura: " + al.getIdFactura());
            System.out.println("ID Hotel: " + al.getIdHotel().getIdHotel());
            System.out.println("ID Reservacion: " + al.getIdReservacion().getIdReservacion());
            System.out.println("ID Detalle: " + al.getIdDetalle().getIdDetalle());
            System.out.println("ID Checkout: " + al.getIdCheckout().getIdCheckout());
            System.out.println("Metodo de Pago: " + al.getMetodoPago());
            System.out.println("NIT: " + al.getNit());
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Fecha Emision: " + formato.format(al.getFechaEmision()));
            SimpleDateFormat formatoo = new SimpleDateFormat("HH:mm:ss");
            System.out.println("Total a Pagar: " + al.getTotalPagar());
        }   
        System.out.println("-------------------");
    }
}
