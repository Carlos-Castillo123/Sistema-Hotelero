/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.CategoriaHabitacion;
import EntityClases.bd.Habitaciones;
import EntityClases.bd.Hotel;
import EntityClases.bd.Huespedes;
import EntityClases.bd.Reservaciones;
import JpaControllers.HabitacionesJpaController;
import JpaControllers.ReservacionesJpaController;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PReservaciones {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
        EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            em = emf.createEntityManager(); // Crear EntityManager
            Reservaciones CH = new Reservaciones();
            System.out.println("Ingresando nueva Reservacion:");
            System.out.println("-----------------------");
            System.out.println("Ingresa ID Hotel:");
            int idhotel = esc.nextInt();
            Hotel hotelid = em.find(Hotel.class, idhotel);
            CH.setIdHotel(hotelid);

            
            System.out.println("Ingresa ID Habitacion:");
            int idhab = esc.nextInt();
            Habitaciones habitacion = em.find(Habitaciones.class, idhab);
            CH.setIdHabitacion(habitacion);

            esc.nextLine(); // Capturar el salto de línea
            System.out.println("Ingresa identificacion:");
            String id = esc.nextLine();
            Huespedes ide = em.find(Huespedes.class, id);
            CH.setIdentificacion(ide);
            
            System.out.println("Ingresa Fecha Reserva (yyyy-MM-dd):");
            String fechaR = esc.nextLine();
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = formato.parse(fechaR);
            CH.setFechaReserva(fecha);
            
            System.out.println("Ingresa Fecha CheckIn(yyyy-MM-dd):");
            String fechaIn = esc.nextLine();
            Date fechasIn = formato.parse(fechaIn);
            CH.setFechaCheckin(fechasIn);
            
            System.out.println("Ingresa Hora CheckIn (hh:mm:ss):");
            String HoraIn = esc.nextLine();
            SimpleDateFormat formatoo = new SimpleDateFormat("HH:mm:ss");
            Date HorasIn = formatoo.parse(HoraIn);
            CH.setHoraCheckin(HorasIn);
            
            System.out.println("Ingresa Cantidad Noches:");
            int noches = esc.nextInt();
            CH.setCantidadNoches(noches);
            
            System.out.println("Disponible(true/false):");
            Boolean dis = esc.nextBoolean();
            CH.setDisponible(dis);
            Double PrecioRoom = habitacion.getPrecioNoche();
            Double tot  = PrecioRoom*noches;
            System.out.println("Total Reservacion: " + tot);
            BigDecimal pagar = BigDecimal.valueOf(tot);
            CH.setTotalReservacion(pagar);
            //Inicia transaccion
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
    
        List<Reservaciones> CHarray = new ArrayList<>();
        ReservacionesJpaController ac = new ReservacionesJpaController(emf);
        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findReservacionesEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (Reservaciones al : CHarray) {
            System.out.println("-------------------");
            System.out.println("ID Reservacion: " + al.getIdReservacion());
            System.out.println("ID Hotel: " + al.getIdHotel().getIdHotel());
            System.out.println("ID Habitacion: " + al.getIdHabitacion().getIdHabitacion());
            System.out.println("Identificacion: " + al.getIdentificacion().getIdentificacion()); 
            
            SimpleDateFormat formatoRes = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Fecha Reserva:"  + formatoRes.format(al.getFechaReserva()));
            
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Fecha ChechIn:"  + formato.format(al.getFechaCheckin()));
            
            SimpleDateFormat formatos = new SimpleDateFormat("HH:mm:ss");
            System.out.println("Hora CheckIn:"  + formatos.format(al.getHoraCheckin()));
            
            System.out.println("Cantidad Noches:"  + al.getCantidadNoches());
            System.out.println("Cantidad Disponible:"  + al.getDisponible());
            System.out.println("Cantidad Total:"  + al.getTotalReservacion());
        }
        System.out.println("-------------------");
    }
}
