/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tablas;

import EntityClases.bd.CategoriaHabitacion;
import JpaControllers.CategoriaHabitacionJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Elacr
 */
public class PCategoriaHabitacion {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_UMG-HOTEL-PROYECT_jar_1.0-SNAPSHOTPU");
            EntityManager em = null;
        Scanner esc = new Scanner(System.in);
        
        try {
            System.out.println("Ingresando nueva Categoria de Habitacion:");
            System.out.println("-----------------------");
            em = emf.createEntityManager(); // Crear EntityManager
            CategoriaHabitacion CH = new CategoriaHabitacion();
            
            System.out.println("Ingresa Descripcion:");
            String descripcion = esc.nextLine();
            CH.setDescripcion(descripcion);
            
            System.out.println("Ingresa cantidad de Camas:");
            int camas = esc.nextInt();
            CH.setCantidadCamas(camas);
            
            em.getTransaction().begin();
            em.persist(CH); // Persistir el objeto
            em.getTransaction().commit(); // Confirmar la transacción
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Hacer rollback si hay error
            }
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager al final
            }
        }
        System.out.println("---------------------");
        // Crear lista para almacenar los datos de la base de datos
        List<CategoriaHabitacion> CHarray = new ArrayList<>();
        CategoriaHabitacionJpaController ac = new CategoriaHabitacionJpaController(emf); // Usar el JpaController

        // Leer datos de la base de datos
        try {
            em = emf.createEntityManager(); // Crear nuevo EntityManager para la lectura
            CHarray = ac.findCategoriaHabitacionEntities(); // Obtener todos los registros
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir traza de la excepción
        } finally {
            if (em != null && em.isOpen()) {
                em.close(); // Cerrar el EntityManager después de la lectura
            }
        }

        // Mostrar todos los datos
        for (CategoriaHabitacion al : CHarray) {
            System.out.println("-------------------");
            System.out.println("Id_CategoriaHabitacion: " + al.getIdCategoria());
            System.out.println("Descripcion: " + al.getDescripcion());
            System.out.println("Camas: " + al.getCantidadCamas());
        }
        System.out.println("-------------------");
    }
}
