/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EntityClases.bd;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Elacr
 */
@Entity
@Table(name = "CHECKOUT", catalog = "UMGHOTEL", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "Checkout.findAll", query = "SELECT c FROM Checkout c")})
public class Checkout implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_checkout", nullable = false)
    private Integer idCheckout;
    @Basic(optional = false)
    @Column(name = "fecha_checkout", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaCheckout;
    @Basic(optional = false)
    @Column(name = "hora_checkout", nullable = false)
    @Temporal(TemporalType.TIME)
    private Date horaCheckout;
    @Column(name = "metodo_pago", length = 255)
    private String metodoPago;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "total_pagar", precision = 53)
    private Double totalPagar;
    @JoinColumn(name = "id_detalle", referencedColumnName = "id_detalle")
    @ManyToOne
    private DetalleFactura idDetalle;
    @JoinColumn(name = "id_reservacion", referencedColumnName = "id_reservacion")
    @ManyToOne
    private Reservaciones idReservacion;
    @OneToMany(mappedBy = "idCheckout")
    private Collection<Facturas> facturasCollection;

    public Checkout() {
    }

    public Checkout(Integer idCheckout) {
        this.idCheckout = idCheckout;
    }

    public Checkout(Integer idCheckout, Date fechaCheckout, Date horaCheckout) {
        this.idCheckout = idCheckout;
        this.fechaCheckout = fechaCheckout;
        this.horaCheckout = horaCheckout;
    }

    public Integer getIdCheckout() {
        return idCheckout;
    }

    public void setIdCheckout(Integer idCheckout) {
        this.idCheckout = idCheckout;
    }

    public Date getFechaCheckout() {
        return fechaCheckout;
    }

    public void setFechaCheckout(Date fechaCheckout) {
        this.fechaCheckout = fechaCheckout;
    }

    public Date getHoraCheckout() {
        return horaCheckout;
    }

    public void setHoraCheckout(Date horaCheckout) {
        this.horaCheckout = horaCheckout;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }

    public DetalleFactura getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(DetalleFactura idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Reservaciones getIdReservacion() {
        return idReservacion;
    }

    public void setIdReservacion(Reservaciones idReservacion) {
        this.idReservacion = idReservacion;
    }

    public Collection<Facturas> getFacturasCollection() {
        return facturasCollection;
    }

    public void setFacturasCollection(Collection<Facturas> facturasCollection) {
        this.facturasCollection = facturasCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCheckout != null ? idCheckout.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Checkout)) {
            return false;
        }
        Checkout other = (Checkout) object;
        if ((this.idCheckout == null && other.idCheckout != null) || (this.idCheckout != null && !this.idCheckout.equals(other.idCheckout))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EntityClases.bd.Checkout[ idCheckout=" + idCheckout + " ]";
    }
    
}
